// This is the program indC_control which is part of the CMWP (Convolutional
// Multiple Whole Profile) fitting program package: http://www.renyi.hu/cmwp
//
// Copyright (C) G�bor Rib�rik, 1998-2009. Distributed under the terms of the
// CMWP Copyright file, see the file CMWP_COPYRIGHT for more details.
//
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.StringTokenizer;

class indC_controlpanel extends JPanel {
    String sample;
    private JTextField C0_field   = new JTextField(4);
    private JCheckBox C0_fix   = new JCheckBox();
    private JTextField C_fix_0   = new JTextField(4);

    private JTextField C1_field   = new JTextField(4);
    private JCheckBox C1_fix   = new JCheckBox();
    private JTextField C_fix_1   = new JTextField(4);

    private JTextField C2_field   = new JTextField(4);
    private JCheckBox C2_fix   = new JCheckBox();
    private JTextField C_fix_2   = new JTextField(4);

    private JTextField C3_field   = new JTextField(4);
    private JCheckBox C3_fix   = new JCheckBox();
    private JTextField C_fix_3   = new JTextField(4);

    private JTextField C4_field   = new JTextField(4);
    private JCheckBox C4_fix   = new JCheckBox();
    private JTextField C_fix_4   = new JTextField(4);

    private JTextField C5_field   = new JTextField(4);
    private JCheckBox C5_fix   = new JCheckBox();
    private JTextField C_fix_5   = new JTextField(4);

    private JTextField C6_field   = new JTextField(4);
    private JCheckBox C6_fix   = new JCheckBox();
    private JTextField C_fix_6   = new JTextField(4);

    private JTextField C7_field   = new JTextField(4);
    private JCheckBox C7_fix   = new JCheckBox();
    private JTextField C_fix_7   = new JTextField(4);

    private JTextField C8_field   = new JTextField(4);
    private JCheckBox C8_fix   = new JCheckBox();
    private JTextField C_fix_8   = new JTextField(4);

    private JTextField C9_field   = new JTextField(4);
    private JCheckBox C9_fix   = new JCheckBox();
    private JTextField C_fix_9   = new JTextField(4);

    private JTextField C10_field   = new JTextField(4);
    private JCheckBox C10_fix   = new JCheckBox();
    private JTextField C_fix_10   = new JTextField(4);

    private JTextField C11_field   = new JTextField(4);
    private JCheckBox C11_fix   = new JCheckBox();
    private JTextField C_fix_11   = new JTextField(4);

    private JTextField C12_field   = new JTextField(4);
    private JCheckBox C12_fix   = new JCheckBox();
    private JTextField C_fix_12   = new JTextField(4);

    private JTextField C13_field   = new JTextField(4);
    private JCheckBox C13_fix   = new JCheckBox();
    private JTextField C_fix_13   = new JTextField(4);

    private JTextField C14_field   = new JTextField(4);
    private JCheckBox C14_fix   = new JCheckBox();
    private JTextField C_fix_14   = new JTextField(4);

    private JTextField C15_field   = new JTextField(4);
    private JCheckBox C15_fix   = new JCheckBox();
    private JTextField C_fix_15   = new JTextField(4);

    private JTextField C16_field   = new JTextField(4);
    private JCheckBox C16_fix   = new JCheckBox();
    private JTextField C_fix_16   = new JTextField(4);

    private JTextField C17_field   = new JTextField(4);
    private JCheckBox C17_fix   = new JCheckBox();
    private JTextField C_fix_17   = new JTextField(4);

    private JTextField C18_field   = new JTextField(4);
    private JCheckBox C18_fix   = new JCheckBox();
    private JTextField C_fix_18   = new JTextField(4);

    private JTextField C19_field   = new JTextField(4);
    private JCheckBox C19_fix   = new JCheckBox();
    private JTextField C_fix_19   = new JTextField(4);

    indC_controlpanel(String samplename) {
        sample=samplename;
        //... Create button and add an action listener
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(new exitlistener());
        JButton SaveButton = new JButton("Save");
        SaveButton.addActionListener(new savelistener());

        //... Set layout and add components.
        //this.setLayout(new FlowLayout());
	// Set the layout with 21 rows by 6 columns
	this.setLayout(new GridLayout(21,6));

        this.add(new JLabel("init_C0: "));
        this.add(C0_field);
        this.add(new JLabel("C0_fixed: "));
        this.add(C0_fix);
        this.add(new JLabel("link_C0_to: "));
        this.add(C_fix_0);

        this.add(new JLabel("init_C1: "));
        this.add(C1_field);
        this.add(new JLabel("C1_fixed: "));
        this.add(C1_fix);
        this.add(new JLabel("link_C1_to: "));
        this.add(C_fix_1);

        this.add(new JLabel("init_C2: "));
        this.add(C2_field);
        this.add(new JLabel("C2_fixed: "));
        this.add(C2_fix);
        this.add(new JLabel("link_C2_to: "));
        this.add(C_fix_2);

        this.add(new JLabel("init_C3: "));
        this.add(C3_field);
        this.add(new JLabel("C3_fixed: "));
        this.add(C3_fix);
        this.add(new JLabel("link_C3_to: "));
        this.add(C_fix_3);

        this.add(new JLabel("init_C4: "));
        this.add(C4_field);
        this.add(new JLabel("C4_fixed: "));
        this.add(C4_fix);
        this.add(new JLabel("link_C4_to: "));
        this.add(C_fix_4);

        this.add(new JLabel("init_C5: "));
        this.add(C5_field);
        this.add(new JLabel("C5_fixed: "));
        this.add(C5_fix);
        this.add(new JLabel("link_C5_to: "));
        this.add(C_fix_5);

        this.add(new JLabel("init_C6: "));
        this.add(C6_field);
        this.add(new JLabel("C6_fixed: "));
        this.add(C6_fix);
        this.add(new JLabel("link_C6_to: "));
        this.add(C_fix_6);

        this.add(new JLabel("init_C7: "));
        this.add(C7_field);
        this.add(new JLabel("C7_fixed: "));
        this.add(C7_fix);
        this.add(new JLabel("link_C7_to: "));
        this.add(C_fix_7);

        this.add(new JLabel("init_C8: "));
        this.add(C8_field);
        this.add(new JLabel("C8_fixed: "));
        this.add(C8_fix);
        this.add(new JLabel("link_C8_to: "));
        this.add(C_fix_8);

        this.add(new JLabel("init_C9: "));
        this.add(C9_field);
        this.add(new JLabel("C9_fixed: "));
        this.add(C9_fix);
        this.add(new JLabel("link_C9_to: "));
        this.add(C_fix_9);

        this.add(new JLabel("init_C10: "));
        this.add(C10_field);
        this.add(new JLabel("C10_fixed: "));
        this.add(C10_fix);
        this.add(new JLabel("link_C10_to: "));
        this.add(C_fix_10);

        this.add(new JLabel("init_C11: "));
        this.add(C11_field);
        this.add(new JLabel("C11_fixed: "));
        this.add(C11_fix);
        this.add(new JLabel("link_C11_to: "));
        this.add(C_fix_11);

        this.add(new JLabel("init_C12: "));
        this.add(C12_field);
        this.add(new JLabel("C12_fixed: "));
        this.add(C12_fix);
        this.add(new JLabel("link_C12_to: "));
        this.add(C_fix_12);

        this.add(new JLabel("init_C13: "));
        this.add(C13_field);
        this.add(new JLabel("C13_fixed: "));
        this.add(C13_fix);
        this.add(new JLabel("link_C13_to: "));
        this.add(C_fix_13);

        this.add(new JLabel("init_C14: "));
        this.add(C14_field);
        this.add(new JLabel("C14_fixed: "));
        this.add(C14_fix);
        this.add(new JLabel("link_C14_to: "));
        this.add(C_fix_14);

        this.add(new JLabel("init_C15: "));
        this.add(C15_field);
        this.add(new JLabel("C15_fixed: "));
        this.add(C15_fix);
        this.add(new JLabel("link_C15_to: "));
        this.add(C_fix_15);

        this.add(new JLabel("init_C16: "));
        this.add(C16_field);
        this.add(new JLabel("C16_fixed: "));
        this.add(C16_fix);
        this.add(new JLabel("link_C16_to: "));
        this.add(C_fix_16);

        this.add(new JLabel("init_C17: "));
        this.add(C17_field);
        this.add(new JLabel("C17_fixed: "));
        this.add(C17_fix);
        this.add(new JLabel("link_C17_to: "));
        this.add(C_fix_17);

        this.add(new JLabel("init_C18: "));
        this.add(C18_field);
        this.add(new JLabel("C18_fixed: "));
        this.add(C18_fix);
        this.add(new JLabel("link_C18_to: "));
        this.add(C_fix_18);

        this.add(new JLabel("init_C19: "));
        this.add(C19_field);
        this.add(new JLabel("C19_fixed: "));
        this.add(C19_fix);
        this.add(new JLabel("link_C19_to: "));
        this.add(C_fix_19);

	this.add(new JLabel(""));
	this.add(new JLabel(""));
        this.add(SaveButton);
        this.add(exitButton);
	this.add(new JLabel(""));
	this.add(new JLabel(""));

	betolt();
    }

    private class exitlistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		System.exit(0);
        }
    }

    private class savelistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		System.out.println("Saving ini files.");
		elment();
        }
    }

    private void elment() {
	elment_fit_ini();
    }

    private void betolt() {
	betolt_fit_ini();
    }

    private void betolt_fit_ini() {
	C0_fix.setSelected(false);
	C1_fix.setSelected(false);
	C2_fix.setSelected(false);
	C3_fix.setSelected(false);
	C4_fix.setSelected(false);
	C5_fix.setSelected(false);
	C6_fix.setSelected(false);
	C7_fix.setSelected(false);
	C8_fix.setSelected(false);
	C9_fix.setSelected(false);
	C0_fix.setSelected(false);
	C11_fix.setSelected(false);
	C12_fix.setSelected(false);
	C13_fix.setSelected(false);
	C14_fix.setSelected(false);
	C15_fix.setSelected(false);
	C16_fix.setSelected(false);
	C17_fix.setSelected(false);
	C18_fix.setSelected(false);
	C19_fix.setSelected(false);
        try {
          BufferedReader r = new BufferedReader(
                               new FileReader(sample+".dat.indC.ini") );
          String line;
          while( (line = r.readLine()) != null ) {
		  StringTokenizer st = new StringTokenizer(line);
		  while ( st.hasMoreTokens() ) {
			  String st1=st.nextToken();
			  String[] st2=st1.split("=", 2);
			  
//			  System.out.println(st2[0]);
//			  System.out.println(st2[1]);
			  if (st2[0].matches("init_C_0"))
				  C0_field.setText(st2[1]);
			  if (st2[0].matches("init_C_1"))
				  C1_field.setText(st2[1]);
			  if (st2[0].matches("init_C_2"))
				  C2_field.setText(st2[1]);
			  if (st2[0].matches("init_C_3"))
				  C3_field.setText(st2[1]);
			  if (st2[0].matches("init_C_4"))
				  C4_field.setText(st2[1]);
			  if (st2[0].matches("init_C_5"))
				  C5_field.setText(st2[1]);
			  if (st2[0].matches("init_C_6"))
				  C6_field.setText(st2[1]);
			  if (st2[0].matches("init_C_7"))
				  C7_field.setText(st2[1]);
			  if (st2[0].matches("init_C_8"))
				  C8_field.setText(st2[1]);
			  if (st2[0].matches("init_C_9"))
				  C9_field.setText(st2[1]);
			  if (st2[0].matches("init_C_10"))
				  C10_field.setText(st2[1]);
			  if (st2[0].matches("init_C_11"))
				  C11_field.setText(st2[1]);
			  if (st2[0].matches("init_C_12"))
				  C12_field.setText(st2[1]);
			  if (st2[0].matches("init_C_13"))
				  C13_field.setText(st2[1]);
			  if (st2[0].matches("init_C_14"))
				  C14_field.setText(st2[1]);
			  if (st2[0].matches("init_C_15"))
				  C15_field.setText(st2[1]);
			  if (st2[0].matches("init_C_16"))
				  C16_field.setText(st2[1]);
			  if (st2[0].matches("init_C_17"))
				  C17_field.setText(st2[1]);
			  if (st2[0].matches("init_C_18"))
				  C18_field.setText(st2[1]);
			  if (st2[0].matches("init_C_19"))
				  C19_field.setText(st2[1]);
			  if (st2[0].matches("C_0_fixed"))
				  C0_fix.setSelected(true);
			  if (st2[0].matches("C_1_fixed"))
				  C1_fix.setSelected(true);
			  if (st2[0].matches("C_2_fixed"))
				  C2_fix.setSelected(true);
			  if (st2[0].matches("C_3_fixed"))
				  C3_fix.setSelected(true);
			  if (st2[0].matches("C_4_fixed"))
				  C4_fix.setSelected(true);
			  if (st2[0].matches("C_5_fixed"))
				  C5_fix.setSelected(true);
			  if (st2[0].matches("C_6_fixed"))
				  C6_fix.setSelected(true);
			  if (st2[0].matches("C_7_fixed"))
				  C7_fix.setSelected(true);
			  if (st2[0].matches("C_8_fixed"))
				  C8_fix.setSelected(true);
			  if (st2[0].matches("C_9_fixed"))
				  C9_fix.setSelected(true);
			  if (st2[0].matches("C_10_fixed"))
				  C10_fix.setSelected(true);
			  if (st2[0].matches("C_11_fixed"))
				  C11_fix.setSelected(true);
			  if (st2[0].matches("C_12_fixed"))
				  C12_fix.setSelected(true);
			  if (st2[0].matches("C_13_fixed"))
				  C13_fix.setSelected(true);
			  if (st2[0].matches("C_14_fixed"))
				  C14_fix.setSelected(true);
			  if (st2[0].matches("C_15_fixed"))
				  C15_fix.setSelected(true);
			  if (st2[0].matches("C_16_fixed"))
				  C16_fix.setSelected(true);
			  if (st2[0].matches("C_17_fixed"))
				  C17_fix.setSelected(true);
			  if (st2[0].matches("C_18_fixed"))
				  C18_fix.setSelected(true);
			  if (st2[0].matches("C_19_fixed"))
				  C19_fix.setSelected(true);
			  if (st2[0].matches("C_fix_0"))
				  C_fix_0.setText(st2[1]);
			  if (st2[0].matches("C_fix_1"))
				  C_fix_1.setText(st2[1]);
			  if (st2[0].matches("C_fix_2"))
				  C_fix_2.setText(st2[1]);
			  if (st2[0].matches("C_fix_3"))
				  C_fix_3.setText(st2[1]);
			  if (st2[0].matches("C_fix_4"))
				  C_fix_4.setText(st2[1]);
			  if (st2[0].matches("C_fix_5"))
				  C_fix_5.setText(st2[1]);
			  if (st2[0].matches("C_fix_6"))
				  C_fix_6.setText(st2[1]);
			  if (st2[0].matches("C_fix_7"))
				  C_fix_7.setText(st2[1]);
			  if (st2[0].matches("C_fix_8"))
				  C_fix_8.setText(st2[1]);
			  if (st2[0].matches("C_fix_9"))
				  C_fix_9.setText(st2[1]);
			  if (st2[0].matches("C_fix_10"))
				  C_fix_10.setText(st2[1]);
			  if (st2[0].matches("C_fix_11"))
				  C_fix_11.setText(st2[1]);
			  if (st2[0].matches("C_fix_12"))
				  C_fix_12.setText(st2[1]);
			  if (st2[0].matches("C_fix_13"))
				  C_fix_13.setText(st2[1]);
			  if (st2[0].matches("C_fix_14"))
				  C_fix_14.setText(st2[1]);
			  if (st2[0].matches("C_fix_15"))
				  C_fix_15.setText(st2[1]);
			  if (st2[0].matches("C_fix_16"))
				  C_fix_16.setText(st2[1]);
			  if (st2[0].matches("C_fix_17"))
				  C_fix_17.setText(st2[1]);
			  if (st2[0].matches("C_fix_18"))
				  C_fix_18.setText(st2[1]);
			  if (st2[0].matches("C_fix_19"))
				  C_fix_19.setText(st2[1]);
		  }
	  }
          r.close();
        } catch (IOException e ) { System.err.println("ERROR reading file."); }
    };

    private void elment_fit_ini() {
	    Process p;
	    String endl = System.getProperty("line.separator");
	    try {
		    PrintWriter w = new PrintWriter(new FileWriter(sample+".dat.indC.ini"));
		    if (C0_field.getText().length()>0) {
			    w.print("init_C_0="+C0_field.getText()+endl);
		    }
		    if (C1_field.getText().length()>0) {
			    w.print("init_C_1="+C1_field.getText()+endl);
		    }
		    if (C2_field.getText().length()>0) {
			    w.print("init_C_2="+C2_field.getText()+endl);
		    }
		    if (C3_field.getText().length()>0) {
			    w.print("init_C_3="+C3_field.getText()+endl);
		    }
		    if (C4_field.getText().length()>0) {
			    w.print("init_C_4="+C4_field.getText()+endl);
		    }
		    if (C5_field.getText().length()>0) {
			    w.print("init_C_5="+C5_field.getText()+endl);
		    }
		    if (C6_field.getText().length()>0) {
			    w.print("init_C_6="+C6_field.getText()+endl);
		    }
		    if (C7_field.getText().length()>0) {
			    w.print("init_C_7="+C7_field.getText()+endl);
		    }
		    if (C8_field.getText().length()>0) {
			    w.print("init_C_8="+C8_field.getText()+endl);
		    }
		    if (C9_field.getText().length()>0) {
			    w.print("init_C_9="+C9_field.getText()+endl);
		    }
		    if (C10_field.getText().length()>0) {
			    w.print("init_C_10="+C10_field.getText()+endl);
		    }
		    if (C11_field.getText().length()>0) {
			    w.print("init_C_11="+C11_field.getText()+endl);
		    }
		    if (C12_field.getText().length()>0) {
			    w.print("init_C_12="+C12_field.getText()+endl);
		    }
		    if (C13_field.getText().length()>0) {
			    w.print("init_C_13="+C13_field.getText()+endl);
		    }
		    if (C14_field.getText().length()>0) {
			    w.print("init_C_14="+C14_field.getText()+endl);
		    }
		    if (C15_field.getText().length()>0) {
			    w.print("init_C_15="+C15_field.getText()+endl);
		    }
		    if (C16_field.getText().length()>0) {
			    w.print("init_C_16="+C16_field.getText()+endl);
		    }
		    if (C17_field.getText().length()>0) {
			    w.print("init_C_17="+C17_field.getText()+endl);
		    }
		    if (C18_field.getText().length()>0) {
			    w.print("init_C_18="+C18_field.getText()+endl);
		    }
		    if (C19_field.getText().length()>0) {
			    w.print("init_C_19="+C19_field.getText()+endl);
		    }
		    if (C0_fix.isSelected())
			    w.print("C_0_fixed=\"y\""+endl);
		    if (C1_fix.isSelected())
			    w.print("C_1_fixed=\"y\""+endl);
		    if (C2_fix.isSelected())
			    w.print("C_2_fixed=\"y\""+endl);
		    if (C3_fix.isSelected())
			    w.print("C_3_fixed=\"y\""+endl);
		    if (C4_fix.isSelected())
			    w.print("C_4_fixed=\"y\""+endl);
		    if (C5_fix.isSelected())
			    w.print("C_5_fixed=\"y\""+endl);
		    if (C6_fix.isSelected())
			    w.print("C_6_fixed=\"y\""+endl);
		    if (C7_fix.isSelected())
			    w.print("C_7_fixed=\"y\""+endl);
		    if (C8_fix.isSelected())
			    w.print("C_8_fixed=\"y\""+endl);
		    if (C9_fix.isSelected())
			    w.print("C_9_fixed=\"y\""+endl);
		    if (C10_fix.isSelected())
			    w.print("C_10_fixed=\"y\""+endl);
		    if (C11_fix.isSelected())
			    w.print("C_11_fixed=\"y\""+endl);
		    if (C12_fix.isSelected())
			    w.print("C_12_fixed=\"y\""+endl);
		    if (C13_fix.isSelected())
			    w.print("C_13_fixed=\"y\""+endl);
		    if (C14_fix.isSelected())
			    w.print("C_14_fixed=\"y\""+endl);
		    if (C15_fix.isSelected())
			    w.print("C_15_fixed=\"y\""+endl);
		    if (C16_fix.isSelected())
			    w.print("C_16_fixed=\"y\""+endl);
		    if (C17_fix.isSelected())
			    w.print("C_17_fixed=\"y\""+endl);
		    if (C18_fix.isSelected())
			    w.print("C_18_fixed=\"y\""+endl);
		    if (C19_fix.isSelected())
			    w.print("C_19_fixed=\"y\""+endl);
		    if (C_fix_0.getText().length()>0) {
			    w.print("C_fix_0="+C_fix_0.getText()+endl);
		    }
		    if (C_fix_1.getText().length()>0) {
			    w.print("C_fix_1="+C_fix_1.getText()+endl);
		    }
		    if (C_fix_2.getText().length()>0) {
			    w.print("C_fix_2="+C_fix_2.getText()+endl);
		    }
		    if (C_fix_3.getText().length()>0) {
			    w.print("C_fix_3="+C_fix_3.getText()+endl);
		    }
		    if (C_fix_4.getText().length()>0) {
			    w.print("C_fix_4="+C_fix_4.getText()+endl);
		    }
		    if (C_fix_5.getText().length()>0) {
			    w.print("C_fix_5="+C_fix_5.getText()+endl);
		    }
		    if (C_fix_6.getText().length()>0) {
			    w.print("C_fix_6="+C_fix_6.getText()+endl);
		    }
		    if (C_fix_7.getText().length()>0) {
			    w.print("C_fix_7="+C_fix_7.getText()+endl);
		    }
		    if (C_fix_8.getText().length()>0) {
			    w.print("C_fix_8="+C_fix_8.getText()+endl);
		    }
		    if (C_fix_9.getText().length()>0) {
			    w.print("C_fix_9="+C_fix_9.getText()+endl);
		    }
		    if (C_fix_10.getText().length()>0) {
			    w.print("C_fix_10="+C_fix_10.getText()+endl);
		    }
		    if (C_fix_11.getText().length()>0) {
			    w.print("C_fix_11="+C_fix_11.getText()+endl);
		    }
		    if (C_fix_12.getText().length()>0) {
			    w.print("C_fix_12="+C_fix_12.getText()+endl);
		    }
		    if (C_fix_13.getText().length()>0) {
			    w.print("C_fix_13="+C_fix_13.getText()+endl);
		    }
		    if (C_fix_14.getText().length()>0) {
			    w.print("C_fix_14="+C_fix_14.getText()+endl);
		    }
		    if (C_fix_15.getText().length()>0) {
			    w.print("C_fix_15="+C_fix_15.getText()+endl);
		    }
		    if (C_fix_16.getText().length()>0) {
			    w.print("C_fix_16="+C_fix_16.getText()+endl);
		    }
		    if (C_fix_17.getText().length()>0) {
			    w.print("C_fix_17="+C_fix_17.getText()+endl);
		    }
		    if (C_fix_18.getText().length()>0) {
			    w.print("C_fix_18="+C_fix_18.getText()+endl);
		    }
		    if (C_fix_19.getText().length()>0) {
			    w.print("C_fix_19="+C_fix_19.getText()+endl);
		    }
		    w.close();

	    } catch (IOException e ) { System.err.println("ERROR writing file."); }
    };

}//end class indC_controlpanel
