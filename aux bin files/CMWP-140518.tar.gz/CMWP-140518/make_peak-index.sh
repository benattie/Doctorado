#! /usr/local/bin/zsh -f
PATH="/home/ribarik/CMWP-121207/progs/bin:/home/ribarik/CMWP-121207/progs/jre1.6.0_12/bin:/home/ribarik/CMWP-121207/progs/libexec/gnuplot/4.2:/home/ribarik/bin.scripts:/home/ribarik/bin.sun4m:/home/ribarik/bin:/usr/local/tool:/usr/local/bin:/usr/local/sbin:/usr/local/samba/bin:/usr/local/bin/TeX:/usr/local/ssl/bin:/usr/local/etc:/usr/local/nmh/bin:/usr/etc:/etc:/usr/hosts:/usr/openwin/bin:/usr/openwin/demo/:/usr/bin/X11:/usr/ucb:/usr/bin:/usr/sbin:/sbin:/bin:/usr/games:/usr/dt/bin:/usr/ccs/bin:/usr/java1.1/bin:/opt/SUNWspro/bin:/opt/SUNWste/bin/:/usr/sadm/bin:/usr/xpg4/bin:/usr/proc/bin:/usr/vmsys/bin:/opt/SUNWrtvc/bin:./bin:.:/usr/local/bin:/usr/bin:/bin:/usr/share/lib:/usr/ccs/bin:/usr/xpg4/bin:$PATH"
# Copyright (C) G�bor Rib�rik, 1998-2009. All rights reserved.
# For permission to use, copy, modify this program or any of its components,
# see the file CMWP_COPYRIGHT.
# Special thanks to Levente Balogh for the preliminary version of this script.

valasz="y"
vared -c -p "Do you want to use logarithmic intensity scale (y/n)?> " valasz

if [[ $valasz = [yYiI]* ]]
then
	gnuplotfile="./lib/make_peak-index-log.gnu"
else
	gnuplotfile="./lib/make_peak-index.gnu"
fi

#ideiglenes fajlok torlese
rm -f tmp/make_peak-index-temp_*(N)

if [[ ! -z $1 ]]
then
    sample=$1
else
    vared -c -p 'Sample name> ' sample
fi

sample=${sample%%.dat}
if [[ ! -e ${sample}.dat ]]
then
    echo "ERROR: cannot find sample file: ${sample}.dat"
    exit 1
fi

if [[ ! -e ${sample}.bg-spline.dat ]]
then
    echo "ERROR: cannot find background spline file: ${sample}.bg-spline.dat"
    exit 2
fi

cp ${sample}.dat tmp/make_peak-index-temp_profile.dat

:> ${sample}.peak-index.dat

valasz="y"

while [[ $valasz = [yYiI]* ]]
do
  gnuplot $gnuplotfile
  twotheta=$(cat tmp/make_peak-index-temp_var.var |grep peak_index_1|awk '{print $3}')
  intensity=$(  cat tmp/make_peak-index-temp_var.var |grep peak_index_2|awk '{print $3}')

  hkl=""
  vared -c -p "Please specify the hkl indices of this peak> " hkl
  if [[ $hkl != *[0-9]*[0-9]*[0-9]* ]]
  then
	echo 'ERROR: You specified an invalid index, please retry!'
	echo 'You have to select the peak again. Press ENTER to continue.'
	read xxx
	continue
  fi

  phase=0
  vared -c -p "Please specify the phase number of this peak (first phase starts with 0)> " phase

  echo $twotheta" "$intensity" "$hkl" "$phase >>${sample}.peak-index.dat

  vared -c -p "Do you want to add another peak (y/n)?> " valasz
done

rm -f tmp/make_peak-index-temp_*(N)

echo "The .peak-index.dat file before background subtraction:"
cat ${sample}.peak-index.dat

let bg_dat_n=0
:> tmp/$$.peak-int-corr.gnu-1
cat ${sample}.bg-spline.dat|tr -d "\r"|grep '^[[:space:]]*[+0-9eE.-][+0-9eE.-]*[[:space:]][[:space:]]*[+0-9eE.-][+0-9eE.-]*[[:space:]]*$'|while read bg_dat_x bg_dat_y
do
  cat << EOF >> tmp/$$.peak-int-corr.gnu-1
bg_dat_x_${bg_dat_n}=${bg_dat_x}
bg_dat_y_${bg_dat_n}=${bg_dat_y}
EOF
  let bg_dat_n+=1
done

if [[ $[${bg_dat_n}<3] = 1 ]]
then
    echo "Error: You have too few data points in ${sample}.bg-spline.dat."
    echo "Minimum number of data points: 3."
    exit 34
fi

	cat << EOF >> tmp/$$.peak-int-corr.gnu-1
use_spline=1
bg_dat_n=${bg_dat_n}
mwp_init
EOF

(
cat ${sample}.peak-index.dat | while read x y hkl
do
	cat tmp/$$.peak-int-corr.gnu-1 >tmp/$$.peak-int-corr.gnu
	cat >>tmp/$$.peak-int-corr.gnu <<EOF
print bgp($x)
EOF
	if [[ $y != 0 ]]
	then
	    i_max_new=$(echo|gawk "{print ($y-$(gnuplot tmp/$$.peak-int-corr.gnu 2>&1|grep -v "MWP mode"))}")
	else
	    i_max_new=0
	fi
	echo ${x}" "${i_max_new}" "${hkl}
done
) >${sample}.peak-index.dat-NEW
cat ${sample}.peak-index.dat-NEW >${sample}.peak-index.dat
rm -f ${sample}.peak-index.dat-NEW

rm -f tmp/$$.peak-int-corr.*(N)

echo "The .peak-index.dat file after background subtraction:"
cat ${sample}.peak-index.dat
