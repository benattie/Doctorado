// This is the program fit-control which is part of the CMWP (Convolutional
// Multiple Whole Profile) fitting program package: http://www.renyi.hu/cmwp
//
// Copyright (C) G�bor Rib�rik, 1998-2009. Distributed under the terms of the
// CMWP Copyright file, see the file CMWP_COPYRIGHT for more details.
//
import java.io.File;
import javax.swing.*;
import javax.swing.filechooser.*;

public class IniFilter extends FileFilter {

	//Accept all directories and all .ini files, but not .q.ini and .fit.ini files.
	public boolean accept(File f) {
		if (f.isDirectory()) {
			return true;
		}

		String ext = null;
		String s = f.getName();
		int i = s.lastIndexOf('.');

		if (i > 0 &&  i < s.length() - 1) {
			ext = s.substring(i+1).toLowerCase();
		}
	
		if (ext != null) {
			if (ext.equals("ini")) {
				String ext2 = null;
				String s2=f.getName().substring(0, i);
				i = s2.lastIndexOf('.');
				if (i > 0 &&  i < s2.length() - 1) {
					ext2 = s2.substring(i+1).toLowerCase();
				}

				if (ext2 != null && ( ext2.equals("q") || ext2.equals("fit"))) {
					return false;
				} else {
					return true;
				}
			} else {
				return false;
			}
		}
		return false;
	}

	//The description of this filter
	public String getDescription() {
		return "Ini Files";
	}
}
