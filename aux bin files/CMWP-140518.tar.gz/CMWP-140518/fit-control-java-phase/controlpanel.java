// This is the program fit-control which is part of the CMWP (Convolutional
// Multiple Whole Profile) fitting program package: http://www.renyi.hu/cmwp
//
// Copyright (C) G�bor Rib�rik, 1998-2009. Distributed under the terms of the
// CMWP Copyright file, see the file CMWP_COPYRIGHT for more details.
//
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.StringTokenizer;

class controlpanel extends JPanel {
    String sample;
    String phase;

    private JCheckBox cryst_cub   = new JCheckBox();
    private JCheckBox cryst_hex   = new JCheckBox();
    private JCheckBox cryst_ort   = new JCheckBox();
    private JTextField lat_a_field   = new JTextField(4);
    private JTextField lat_b_field   = new JTextField(4);
    private JTextField lat_c_field   = new JTextField(4);
    private JTextField C_field   = new JTextField(4);
    private JTextField burgers_field   = new JTextField(4);
    private JTextField wavelength_field   = new JTextField(4);

    private JCheckBox NO_SIZE_EFFECT   = new JCheckBox();
    private JCheckBox SF_ELLIPSOIDAL   = new JCheckBox();

    private JCheckBox INDC   = new JCheckBox();
    private JCheckBox USE_STACKING   = new JCheckBox();

    private JCheckBox USE_WEIGHTS   = new JCheckBox();
    private JCheckBox peak_int_fit   = new JCheckBox();
    private JCheckBox peak_pos_fit   = new JCheckBox();
    private JCheckBox disable_coinc_g2   = new JCheckBox();

    private JCheckBox ENABLE_CONVOLUTION   = new JCheckBox();
    private JTextField INSTSRCDIR_field   = new JTextField(4);

    private JCheckBox fit_in_K = new JCheckBox();
    private JCheckBox CLONE2   = new JCheckBox();
    private JCheckBox CLONE3   = new JCheckBox();

    private JTextField IF_TH_FT_limit_field   = new JTextField(4);
    private JTextField PROF_CUT_field   = new JTextField(4);

    private JTextField N1_field   = new JTextField(4);
    private JTextField N2_field   = new JTextField(4);

    private JTextField minx_field   = new JTextField(4);
    private JTextField maxx_field   = new JTextField(4);

    private JTextField FIT_LIMIT_field   = new JTextField(4);
    private JTextField FIT_MAXITER_field   = new JTextField(4);

    private JTextField a1_field   = new JTextField(4);
    private JTextField a2_field   = new JTextField(4);
    private JTextField a3_field   = new JTextField(4);
    private JTextField a4_field   = new JTextField(4);
    private JTextField a5_field   = new JTextField(4);
    private JTextField eps_field   = new JTextField(4);
    private JTextField a_field   = new JTextField(4);
    private JCheckBox a_fix   = new JCheckBox();
    private JCheckBox a1_fix   = new JCheckBox();
    private JCheckBox a2_fix   = new JCheckBox();
    private JCheckBox a3_fix   = new JCheckBox();
    private JCheckBox a4_fix   = new JCheckBox();
    private JCheckBox a5_fix   = new JCheckBox();
    private JCheckBox eps_fix   = new JCheckBox();
    private JTextField scale_a   = new JTextField(4);

    private JTextField b_field   = new JTextField(4);
    private JCheckBox b_fix   = new JCheckBox();
    private JTextField scale_b   = new JTextField(4);

    private JTextField c_field   = new JTextField(4);
    private JCheckBox c_fix   = new JCheckBox();
    private JTextField scale_c   = new JTextField(4);

    private JTextField d_field   = new JTextField(4);
    private JCheckBox d_fix   = new JCheckBox();
    private JTextField scale_d   = new JTextField(4);

    private JTextField e_field   = new JTextField(4);
    private JCheckBox e_fix   = new JCheckBox();
    private JTextField scale_e   = new JTextField(4);

    private JCheckBox de_fix   = new JCheckBox();

    private JTextField st_pr_field   = new JTextField(4);
    private JCheckBox st_pr_fix   = new JCheckBox();
    private JTextField STACKING_field   = new JTextField(4);

    private JFrame instsrcdir_frame = new JFrame();
    private JFileChooser instsrcdir_chooser=new INSTSRCDIR_FileChooser();
    private boolean instsrcdir_chooser_opened=false;

    private JFrame stacking_frame = new JFrame();
    private JFileChooser stacking_chooser=new STACKING_FileChooser();
    private boolean stacking_chooser_opened=false;

    private JFrame clone_frame = new JFrame();
    private JFileChooser clone_chooser=new CLONE_FileChooser();
    private boolean clone_chooser_opened=false;

    private JTextField phase_num_field   = new JTextField(4);
    private JTextField edit_phase_field   = new JTextField(4);

    controlpanel(String samplename) {

//      sample=samplename;

        StringTokenizer stt = new StringTokenizer(samplename);

	String stt1=stt.nextToken();
	String stt2[]=stt1.split("=", 2);

	sample=stt2[0];
	phase=stt2[1];
			  
	System.out.println("Sample: "+sample);
	System.out.println("Phase: "+phase);

        //... Create button and add an action listener
        JButton runButton = new JButton("(Re)Start FIT");
        runButton.addActionListener(new runlistener());
        JButton stopButton = new JButton("Stop FIT");
        stopButton.addActionListener(new stoplistener());
        JButton updateButton = new JButton("Update Params");
        updateButton.addActionListener(new updatelistener());
        JButton viewpButton = new JButton("View Solutions");
        viewpButton.addActionListener(new viewplistener());
        JButton viewfButton = new JButton("View FIT");
        viewfButton.addActionListener(new viewflistener());
        JButton exitButton = new JButton("Save & Exit");
        exitButton.addActionListener(new exitlistener());
        JButton MKSplineButton = new JButton("Call MKSpline");
        MKSplineButton.addActionListener(new mksplinelistener());
        JButton MKSplineTwoButton = new JButton("Call MKSpline2");
        MKSplineTwoButton.addActionListener(new mksplinetwolistener());
        JButton IndexButton = new JButton("Index peaks");
        IndexButton.addActionListener(new make_peak_index_listener());
        JButton IndCButton = new JButton("Set individ. C values");
        IndCButton.addActionListener(new indClistener());
        JButton SaveIniButton = new JButton("Save INI files");
        SaveIniButton.addActionListener(new saveinilistener());
        JButton CloneIniButton = new JButton("Clone INI files");
        CloneIniButton.addActionListener(new cloneinilistener());
        JButton BrowseInstrButton = new JButton("Browse");
        BrowseInstrButton.addActionListener(new browseinstlistener());
        JButton BrowseStackingButton = new JButton("Browse");
        BrowseStackingButton.addActionListener(new browsestackinglistener());

        JButton EditPhaseButton = new JButton("Edit Selected Phase");
        EditPhaseButton.addActionListener(new editphaselistener());

        //... Set layout and add components.
        //this.setLayout(new FlowLayout());
	// Set the layout with 13 rows by 6 columns
	this.setLayout(new GridLayout(13,6));
        this.add(new JLabel("CUBIC: "));
        this.add(cryst_cub);
        this.add(new JLabel("HEXAGONAL: "));
        this.add(cryst_hex);
        this.add(new JLabel("ORTHOROMBIC: "));
        this.add(cryst_ort);
        this.add(new JLabel("lat_a (CUB|HEX|ORT) [nm]: "));
        this.add(lat_a_field);
        this.add(new JLabel("lat_b (ORT) [nm]: "));
        this.add(lat_b_field);
        this.add(new JLabel("lat_c (HEX|ORT) [nm]: "));
        this.add(lat_c_field);
        this.add(new JLabel("Burgers vector [nm]: "));
        this.add(burgers_field);
        this.add(new JLabel(""));
        this.add(new JLabel(""));
        this.add(new JLabel("Ch00 or Chk0: "));
        this.add(C_field);

        this.add(new JLabel("init_a (CUB): "));
        this.add(a_field);
        this.add(new JLabel("init_a1 (HEX|ORT): "));
        this.add(a1_field);
        this.add(new JLabel("init_a2 (HEX|ORT): "));
        this.add(a2_field);
        this.add(new JLabel("a_fixed: "));
        this.add(a_fix);
        this.add(new JLabel("a1_fixed: "));
        this.add(a1_fix);
        this.add(new JLabel("a2_fixed: "));
        this.add(a2_fix);
        this.add(new JLabel("init_a3 (ORT): "));
        this.add(a3_field);
        this.add(new JLabel("init_a4 (ORT): "));
        this.add(a4_field);
        this.add(new JLabel("init_a5 (ORT): "));
        this.add(a5_field);
        this.add(new JLabel("a3_fixed: "));
        this.add(a3_fix);
        this.add(new JLabel("a4_fixed: "));
        this.add(a4_fix);
        this.add(new JLabel("a5_fixed: "));
        this.add(a5_fix);

        this.add(new JLabel("init_b: "));
        this.add(b_field);
        this.add(new JLabel("b_fixed: "));
        this.add(b_fix);
        this.add(new JLabel(""));
        this.add(new JLabel(""));

        this.add(new JLabel("init_c: "));
        this.add(c_field);
        this.add(new JLabel("c_fixed: "));
        this.add(c_fix);
        this.add(new JLabel(""));
        this.add(new JLabel(""));

        this.add(new JLabel("init_d: "));
        this.add(d_field);
        this.add(new JLabel("d_fixed: "));
        this.add(d_fix);
        this.add(new JLabel(""));
        this.add(new JLabel(""));

        this.add(new JLabel("init_e: "));
        this.add(e_field);
        this.add(new JLabel("e_fixed: "));
        this.add(e_fix);
        this.add(new JLabel(""));
        this.add(new JLabel(""));

        this.add(new JLabel("d*e_fixed: "));
        this.add(de_fix);
        this.add(new JLabel(""));
        this.add(new JLabel(""));
        this.add(new JLabel(""));
        this.add(new JLabel(""));

        this.add(exitButton);
        this.add(new JLabel(""));
        this.add(new JLabel(""));
        this.add(new JLabel(""));
        this.add(new JLabel(""));
        this.add(new JLabel(""));

	betolt();
    }

    private class runlistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./lib/kill_fit", sample} );
			try {
				p.waitFor();
				System.out.println("Kill_fit finished.");
			}
			catch ( InterruptedException ex2 )
			{
				Thread.currentThread().interrupt();
			}
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command kill_fit.");
		}

		elment();
    
		String datname=sample;
		try {
			File datf = new File(new File(sample+".dat").getCanonicalPath());
			if (datf.exists() == true && datf.isDirectory() == false) {
				datname=sample+".dat";
			}
		} catch (IOException exf ) {}

		System.out.println("Running: ./evaluate-int "+datname+" auto");

		//Example:
		//Runtime.getRuntime().exec( new String[]{ "/bin/sh", "-c", "echo $SHELL"} );

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "zsh", "-fc", "./evaluate-int "+datname+" auto"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running evaluate-int.");
		}
        }
    }

    private class stoplistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./lib/kill_fit", sample} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command kill_fit.");
		}
        }
    }

    private class updatelistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "./lib/update_fit_ini", sample+".dat"} );
			try {
				p.waitFor();
				System.out.println("Update finished.");
			}
			catch ( InterruptedException ex2 )
			{
				Thread.currentThread().interrupt();
			}
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command update_fit_ini.");
		}
		betolt();
        }
    }

    private class viewplistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "less", "+G", sample+".sol"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command less.");
		}
        }
    }

    private class viewflistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "gv", sample+".int.ps"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command gv.");
		}
        }
    }

    private class exitlistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		System.out.println("Saving ini files.");
		elment();
		System.exit(0);
        }
    }

    private class make_peak_index_listener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./make_peak-index.sh", sample} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command make_peak-index.sh.");
		}
        }
    }

    private class mksplinelistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./mkspline", sample+".dat"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command mkspline.");
		}
        }
    }

    private class mksplinetwolistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./mkspline2", sample+".dat"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command mkspline2.");
		}
        }
    }

    private class indClistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./set_individ_C", sample+".dat"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command set_individ_C.");
		}
        }
    }

    private class editphaselistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./evaluate-control-phase", sample+".dat", edit_phase_field.getText()} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command evaluate-control-phase");
		}
        }
    }

    private class saveinilistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		System.out.println("Saving ini files.");
		elment();
        }
    }

    private class cloneinilistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

		try {
			clone_frame.setVisible(true);
			clone_frame.setSize(640,480);

//			clone_chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			clone_chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
//			clone_chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			clone_chooser.addChoosableFileFilter(new IniFilter());
			clone_chooser.setAcceptAllFileFilterUsed(false);
			if (clone_chooser_opened==false) {
				clone_chooser_opened=true;
				// get the current directory
				File f = new File(new File(".").getCanonicalPath());
				
				// Set the current directory
				clone_chooser.setCurrentDirectory(f);
			}
			clone_frame.add(clone_chooser);
			clone_chooser.rescanCurrentDirectory();
		} catch (Exception ex1) {
			System.err.println("Error creating new window.");
		}
        }
    }

    private class browseinstlistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

		if (ENABLE_CONVOLUTION.isSelected() == false)
			return;

		try {
			instsrcdir_frame.setVisible(true);
			instsrcdir_frame.setSize(640,480);

//			instsrcdir_chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
//			instsrcdir_chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			instsrcdir_chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			if (instsrcdir_chooser_opened==false) {
				instsrcdir_chooser_opened=true;
				// get the current directory
				if (INSTSRCDIR_field.getText().length()>0) {
					File f = new File(new File(INSTSRCDIR_field.getText()).getCanonicalPath());
    
					// Set the current directory
					instsrcdir_chooser.setCurrentDirectory(f);
				} else {
					File f = new File(new File(".").getCanonicalPath());
    
					// Set the current directory
					instsrcdir_chooser.setCurrentDirectory(f);
				}
			}
			instsrcdir_frame.add(instsrcdir_chooser);
			instsrcdir_chooser.rescanCurrentDirectory();
		} catch (Exception ex1) {
			System.err.println("Error creating new window.");
		}
        }
    }

    private class browsestackinglistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

		if (USE_STACKING.isSelected() == false)
			return;

		try {
			stacking_frame.setVisible(true);
			stacking_frame.setSize(640,480);

//			stacking_chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			stacking_chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
//			stacking_chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			if (stacking_chooser_opened==false) {
				stacking_chooser_opened=true;
				// get the current directory
				if (STACKING_field.getText().length()>0) {
					File f = new File(new File(STACKING_field.getText()).getCanonicalPath());
    
					// Set the current directory
					stacking_chooser.setCurrentDirectory(f);
				} else {
					File f = new File(new File(".").getCanonicalPath());
    
					// Set the current directory
					stacking_chooser.setCurrentDirectory(f);
				}
			}
			stacking_frame.add(stacking_chooser);
			stacking_chooser.rescanCurrentDirectory();
		} catch (Exception ex1) {
			System.err.println("Error creating new window.");
		}
        }
    }

    private void elment() {
	elment_ini();
//	elment_q_ini();
	elment_fit_ini();
    }

    private void betolt() {
	betolt_ini();
//	betolt_q_ini();
	betolt_fit_ini();
    }

    private void betolt_ini() {
	cryst_cub.setSelected(false);
	cryst_hex.setSelected(false);
	cryst_ort.setSelected(false);
	boolean lb_set=false;
	boolean lc_set=false;
        try {
          BufferedReader r = new BufferedReader(
                               new FileReader(sample+".dat.ini.ph"+phase) );
          String line;
          while( (line = r.readLine()) != null ) {
		  StringTokenizer st = new StringTokenizer(line);
		  while ( st.hasMoreTokens() ) {
			  String st1=st.nextToken();
			  String[] st2=st1.split("=", 2);
			  
//			  System.out.println(st2[0]);
//			  System.out.println(st2[1]);
			  if (st2[0].matches("la_"+phase))
				  lat_a_field.setText(st2[1]);
			  if (st2[0].matches("lb_"+phase)) {
				  lat_b_field.setText(st2[1]);
				  lb_set=true;
			  }
			  if (st2[0].matches("lc_"+phase)) {
				  lat_c_field.setText(st2[1]);
				  lc_set=true;
			  }
			  if (st2[0].matches("bb_"+phase))
				  burgers_field.setText(st2[1]);
			  if (st2[0].matches("C0_"+phase))
				  C_field.setText(st2[1]);
		  }
	  }
          r.close();
        } catch (IOException e ) { System.err.println("ERROR reading file."); }
	if (lc_set==true) {
	    if (lb_set==true) {
		cryst_ort.setSelected(true);
	    } else {
		cryst_hex.setSelected(true);
	    }
	} else {
	    cryst_cub.setSelected(true);
	}
    }

    private void elment_ini() {
	    String endl = System.getProperty("line.separator");
	    try {
		    PrintWriter w = new PrintWriter(new FileWriter(sample+".dat.ini.ph"+phase));
		    w.print("la_"+phase+"="+lat_a_field.getText()+endl);
		    if (cryst_ort.isSelected()) {
			w.print("lb_"+phase+"="+lat_b_field.getText()+endl);
		    }
		    if (cryst_hex.isSelected() || cryst_ort.isSelected()) {
			w.print("lc_"+phase+"="+lat_c_field.getText()+endl);
		    }
		    w.print("bb_"+phase+"="+burgers_field.getText()+endl);
		    w.print("C0_"+phase+"="+C_field.getText()+endl);
		    w.close();
	    } catch (IOException e ) { System.err.println("ERROR writing file."); }
    }

    private void betolt_q_ini() {
	NO_SIZE_EFFECT.setSelected(false);
	SF_ELLIPSOIDAL.setSelected(false);
	INDC.setSelected(false);
	USE_STACKING.setSelected(false);
	USE_WEIGHTS.setSelected(false);
	peak_int_fit.setSelected(false);
	peak_pos_fit.setSelected(false);
	fit_in_K.setSelected(false);
	disable_coinc_g2.setSelected(false);
	ENABLE_CONVOLUTION.setSelected(false);
	CLONE2.setSelected(false);
	CLONE3.setSelected(false);
        try {
          BufferedReader r = new BufferedReader(
                               new FileReader(sample+".dat.q.ini") );
          String line;
          while( (line = r.readLine()) != null ) {
		  StringTokenizer st = new StringTokenizer(line);
		  while ( st.hasMoreTokens() ) {
			  String st1=st.nextToken();
			  String[] st2=st1.split("=", 2);
			  
//			  System.out.println(st2[0]);
//			  System.out.println(st2[1]);
			  if (st2[0].matches("NO_SIZE_EFFECT") && st2[1].matches("y"))
				  NO_SIZE_EFFECT.setSelected(true);
			  if (st2[0].matches("SF_ELLIPSOIDAL") && st2[1].matches("y"))
				  SF_ELLIPSOIDAL.setSelected(true);
			  if (st2[0].matches("INDC") && st2[1].matches("y"))
				  INDC.setSelected(true);
			  if (st2[0].matches("USE_STACKING") && st2[1].matches("y"))
				  USE_STACKING.setSelected(true);
			  if (st2[0].matches("STACKING_DAT"))
				  STACKING_field.setText(st2[1]);
			  if (st2[0].matches("USE_WEIGHTS") && st2[1].matches("y"))
				  USE_WEIGHTS.setSelected(true);
			  if (st2[0].matches("peak_int_fit") && st2[1].matches("y"))
				  peak_int_fit.setSelected(true);
			  if (st2[0].matches("peak_pos_fit") && st2[1].matches("y"))
				  peak_pos_fit.setSelected(true);
			  if (st2[0].matches("fit_in_K") && st2[1].matches("y"))
				  fit_in_K.setSelected(true);
			  if (st2[0].matches("DISABLE_COINC_G2") && st2[1].matches("y"))
				  disable_coinc_g2.setSelected(true);
			  if (st2[0].matches("ENABLE_CONVOLUTION") && st2[1].matches("y"))
				  ENABLE_CONVOLUTION.setSelected(true);
			  if (st2[0].matches("INSTSRCDIR"))
				  INSTSRCDIR_field.setText(st2[1]);
			  if (st2[0].matches("IF_TH_FT_limit"))
				  IF_TH_FT_limit_field.setText(st2[1]);
			  if (st2[0].matches("PROF_CUT"))
				  PROF_CUT_field.setText(st2[1]);
			  if (st2[0].matches("N1"))
				  N1_field.setText(st2[1]);
			  if (st2[0].matches("N2"))
				  N2_field.setText(st2[1]);
			  if (st2[0].matches("minx"))
				  minx_field.setText(st2[1]);
			  if (st2[0].matches("maxx"))
				  maxx_field.setText(st2[1]);
			  if (st2[0].matches("FIT_LIMIT"))
				  FIT_LIMIT_field.setText(st2[1]);
			  if (st2[0].matches("FIT_MAXITER"))
				  FIT_MAXITER_field.setText(st2[1]);
		  }
	  }
          r.close();
        } catch (IOException e ) { System.err.println("ERROR reading file."); }
    }

    private void elment_q_ini() {
	    String endl = System.getProperty("line.separator");
	    try {
		    PrintWriter w = new PrintWriter(new FileWriter(sample+".dat.q.ini.ph"+phase));
		    w.print("USE_SPLINE=y"+endl);
		    if (NO_SIZE_EFFECT.isSelected())
			w.print("NO_SIZE_EFFECT=y"+endl);
		    else
			w.print("NO_SIZE_EFFECT=n"+endl);
		    if (SF_ELLIPSOIDAL.isSelected())
			w.print("SF_ELLIPSOIDAL=y"+endl);
		    else
			w.print("SF_ELLIPSOIDAL=n"+endl);
		    if (INDC.isSelected())
			w.print("INDC=y"+endl);
		    else
			w.print("INDC=n"+endl);
		    if (USE_STACKING.isSelected()) {
			w.print("USE_STACKING=y"+endl);
			if (STACKING_field.getText().length()>0) {
				w.print("STACKING_DAT="+STACKING_field.getText()+endl);
			}
		    } else
			w.print("USE_STACKING=n"+endl);
		    if (USE_WEIGHTS.isSelected())
			w.print("USE_WEIGHTS=y"+endl);
		    else
			w.print("USE_WEIGHTS=n"+endl);
		    if (peak_int_fit.isSelected())
			w.print("peak_int_fit=y"+endl);
		    else
			w.print("peak_int_fit=n"+endl);
		    if (peak_pos_fit.isSelected())
			w.print("peak_pos_fit=y"+endl);
		    else
			w.print("peak_pos_fit=n"+endl);
		    if (fit_in_K.isSelected())
			w.print("fit_in_K=y"+endl);
		    else
			w.print("fit_in_K=n"+endl);
		    if (disable_coinc_g2.isSelected())
			w.print("DISABLE_COINC_G2=y"+endl);
		    else
			w.print("DISABLE_COINC_G2=n"+endl);
		    if (ENABLE_CONVOLUTION.isSelected()) {
			w.print("ENABLE_CONVOLUTION=y"+endl);
			if (INSTSRCDIR_field.getText().length()>0) {
				w.print("INSTSRCDIR="+INSTSRCDIR_field.getText()+endl);
			}
		    } else {
			w.print("ENABLE_CONVOLUTION=n"+endl);
			w.print("IF_TH_FT_limit="+IF_TH_FT_limit_field.getText()+endl);
		    }
		    w.print("PROF_CUT="+PROF_CUT_field.getText()+endl);
		    w.print("N1="+N1_field.getText()+endl);
		    w.print("N2="+N2_field.getText()+endl);
		    w.print("minx="+minx_field.getText()+endl);
		    w.print("maxx="+maxx_field.getText()+endl);
		    w.print("FIT_LIMIT="+FIT_LIMIT_field.getText()+endl);
		    w.print("FIT_MAXITER="+FIT_MAXITER_field.getText()+endl);
		    w.close();
	    } catch (IOException e ) { System.err.println("ERROR writing file."); }
    };

    private void betolt_fit_ini() {
	a_fix.setSelected(false);
	a1_fix.setSelected(false);
	a2_fix.setSelected(false);
	a3_fix.setSelected(false);
	a4_fix.setSelected(false);
	a5_fix.setSelected(false);
	b_fix.setSelected(false);
	c_fix.setSelected(false);
	d_fix.setSelected(false);
	e_fix.setSelected(false);
	de_fix.setSelected(false);
	eps_fix.setSelected(false);
	st_pr_fix.setSelected(false);
        try {
          BufferedReader r = new BufferedReader(
                               new FileReader(sample+".dat.fit.ini.ph"+phase) );
          String line;
          while( (line = r.readLine()) != null ) {
		  StringTokenizer st = new StringTokenizer(line);
		  while ( st.hasMoreTokens() ) {
			  String st1=st.nextToken();
			  String[] st2=st1.split("=", 2);
			  
//			  System.out.println(st2[0]);
//			  System.out.println(st2[1]);
			  if (st2[0].matches("init_a"+"_"+phase))
				  a_field.setText(st2[1]);
			  if (st2[0].matches("init_a1"+"_"+phase))
				  a1_field.setText(st2[1]);
			  if (st2[0].matches("init_a2"+"_"+phase))
				  a2_field.setText(st2[1]);
			  if (st2[0].matches("init_a3"+"_"+phase))
				  a3_field.setText(st2[1]);
			  if (st2[0].matches("init_a4"+"_"+phase))
				  a4_field.setText(st2[1]);
			  if (st2[0].matches("init_a5"+"_"+phase))
				  a5_field.setText(st2[1]);
			  if (st2[0].matches("init_b"+"_"+phase))
				  b_field.setText(st2[1]);
			  if (st2[0].matches("init_c"+"_"+phase))
				  c_field.setText(st2[1]);
			  if (st2[0].matches("init_d"+"_"+phase))
				  d_field.setText(st2[1]);
			  if (st2[0].matches("init_e"+"_"+phase))
				  e_field.setText(st2[1]);
			  if (st2[0].matches("a_"+phase+"_fixed"))
				  a_fix.setSelected(true);
			  if (st2[0].matches("a1_"+phase+"_fixed"))
				  a1_fix.setSelected(true);
			  if (st2[0].matches("a2_"+phase+"_fixed"))
				  a2_fix.setSelected(true);
			  if (st2[0].matches("a3_"+phase+"_fixed"))
				  a3_fix.setSelected(true);
			  if (st2[0].matches("a4_"+phase+"_fixed"))
				  a4_fix.setSelected(true);
			  if (st2[0].matches("a5_"+phase+"_fixed"))
				  a5_fix.setSelected(true);
			  if (st2[0].matches("b_"+phase+"_fixed"))
				  b_fix.setSelected(true);
			  if (st2[0].matches("c_"+phase+"_fixed"))
				  c_fix.setSelected(true);
			  if (st2[0].matches("d_"+phase+"_fixed"))
				  d_fix.setSelected(true);
			  if (st2[0].matches("e_"+phase+"_fixed"))
				  e_fix.setSelected(true);
			  if (st2[0].matches("de_"+phase+"_fixed"))
				  de_fix.setSelected(true);
		  }
	  }
          r.close();
        } catch (IOException e ) { System.err.println("ERROR reading file."); }
    };

    private void elment_fit_ini() {
	    Process p;
	    String endl = System.getProperty("line.separator");
	    try {
		    PrintWriter w = new PrintWriter(new FileWriter(sample+".dat.fit.ini.ph"+phase));
		    if (a_field.getText().length()>0) {
			    w.print("init_a_"+phase+"="+a_field.getText()+endl);
		    } else {
			    w.print("init_a_"+phase+"=1.0"+endl);
		    }
		    if (a1_field.getText().length()>0) {
			    w.print("init_a1_"+phase+"="+a1_field.getText()+endl);
		    } else {
			    w.print("init_a1_"+phase+"=1.0"+endl);
		    }
		    if (a2_field.getText().length()>0) {
			    w.print("init_a2_"+phase+"="+a2_field.getText()+endl);
		    } else {
			    w.print("init_a2_"+phase+"=1.0"+endl);
		    }
		    if (a3_field.getText().length()>0) {
			    w.print("init_a3_"+phase+"="+a3_field.getText()+endl);
		    } else {
			    w.print("init_a3_"+phase+"=1.0"+endl);
		    }
		    if (a4_field.getText().length()>0) {
			    w.print("init_a4_"+phase+"="+a4_field.getText()+endl);
		    } else {
			    w.print("init_a4_"+phase+"=1.0"+endl);
		    }
		    if (a5_field.getText().length()>0) {
			    w.print("init_a5_"+phase+"="+a5_field.getText()+endl);
		    } else {
			    w.print("init_a5_"+phase+"=1.0"+endl);
		    }
		    if (b_field.getText().length()>0) {
			    w.print("init_b_"+phase+"="+b_field.getText()+endl);
		    } else {
			    w.print("init_b_"+phase+"=1.0"+endl);
		    }
		    if (c_field.getText().length()>0) {
			    w.print("init_c_"+phase+"="+c_field.getText()+endl);
		    } else {
			    w.print("init_c_"+phase+"=1.0"+endl);
		    }
		    if (d_field.getText().length()>0) {
			    w.print("init_d_"+phase+"="+d_field.getText()+endl);
		    } else {
			    w.print("init_d_"+phase+"=1.0"+endl);
		    }
		    if (e_field.getText().length()>0) {
			    w.print("init_e_"+phase+"="+e_field.getText()+endl);
		    } else {
			    w.print("init_e_"+phase+"=1.0"+endl);
		    }
		    if (a_fix.isSelected())
			    w.print("a_"+phase+"_fixed=\"y\""+endl);
		    if (a1_fix.isSelected())
			    w.print("a1_"+phase+"_fixed=\"y\""+endl);
		    if (a2_fix.isSelected())
			    w.print("a2_"+phase+"_fixed=\"y\""+endl);
		    if (a3_fix.isSelected())
			    w.print("a3_"+phase+"_fixed=\"y\""+endl);
		    if (a4_fix.isSelected())
			    w.print("a4_"+phase+"_fixed=\"y\""+endl);
		    if (a5_fix.isSelected())
			    w.print("a5_"+phase+"_fixed=\"y\""+endl);
		    if (b_fix.isSelected())
			    w.print("b_"+phase+"_fixed=\"y\""+endl);
		    if (c_fix.isSelected())
			    w.print("c_"+phase+"_fixed=\"y\""+endl);
		    if (d_fix.isSelected())
			    w.print("d_"+phase+"_fixed=\"y\""+endl);
		    if (e_fix.isSelected())
			    w.print("e_"+phase+"_fixed=\"y\""+endl);
		    if (de_fix.isSelected())
			    w.print("de_"+phase+"_fixed=\"y\""+endl);
		    w.close();

	    } catch (IOException e ) { System.err.println("ERROR writing file."); }
    };

    class INSTSRCDIR_FileChooser extends JFileChooser {
    // A leiras rola itt van:
    // http://java.sun.com/docs/books/tutorial/uiswing/components/filechooser.html
	    public void approveSelection() {
		    File f=getSelectedFile();

//		    String name=getName(f);
		    String name=f.getPath();
//		    System.out.println("Open button pressed, file name: "+name);
		    if (f.exists() == true && f.isDirectory() == true) {
			    try {
				    File cwdf = new File(new File(".").getCanonicalPath());
				    String cwd=cwdf.getPath();

				    int cwdlength=(int) cwd.length()+1;

				    if (name.startsWith(cwd)) {
					    INSTSRCDIR_field.setText(name.substring(cwdlength));
				    } else {
					    INSTSRCDIR_field.setText(name);
				    }
			    } catch (IOException e ) { System.err.println("ERROR getting path name of current directory."); }
			    instsrcdir_frame.setVisible(false);
		    }
	    }

	    public void cancelSelection() {
//		    System.out.println("Cancel button pressed.");
		    instsrcdir_frame.setVisible(false);
	    }
    };

    class STACKING_FileChooser extends JFileChooser {
    // A leiras rola itt van:
    // http://java.sun.com/docs/books/tutorial/uiswing/components/filechooser.html
	    public void approveSelection() {
		    File f=getSelectedFile();

//		    String name=getName(f);
		    String name=f.getPath();
//		    System.out.println("Open button pressed, file name: "+name);
		    if (f.exists() == true && f.isDirectory() == false) {
			    try {
				    File cwdf = new File(new File(".").getCanonicalPath());
				    String cwd=cwdf.getPath();

				    int cwdlength=(int) cwd.length()+1;

				    if (name.startsWith(cwd)) {
					    STACKING_field.setText(name.substring(cwdlength));
				    } else {
					    STACKING_field.setText(name);
				    }
			    } catch (IOException e ) { System.err.println("ERROR getting path name of current directory."); }
			    stacking_frame.setVisible(false);
		    }
	    }

	    public void cancelSelection() {
//		    System.out.println("Cancel button pressed.");
		    stacking_frame.setVisible(false);
	    }
    };


    class CLONE_FileChooser extends JFileChooser {
	    Process p;

	    public void approveSelection() {
		    File f=getSelectedFile();

//		    String name=getName(f);
		    String name=f.getPath();
//		    System.out.println("Open button pressed, file name: "+name);
		    if (f.exists() == true && f.isDirectory() == false) {
			    try {
				    p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./lib/clone_ini", name, sample} );
				    try {
					    p.waitFor();
					    System.out.println("clone_ini finished.");
				    }
				    catch ( InterruptedException ex2 )
				    {
					    Thread.currentThread().interrupt();
				    }
				    if (CLONE2.isSelected()) {
      				      p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./lib/clone_ini2", name, sample} );
      				      try {
					    p.waitFor();
					    System.out.println("clone_ini2 finished.");
                                      }
                                      catch ( InterruptedException ex2 )
				      {
					    Thread.currentThread().interrupt();
				      }
				    }
				    if (CLONE3.isSelected()) {
      				      p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./lib/clone_ini3", name, sample} );
      				      try {
					    p.waitFor();
					    System.out.println("clone_ini3 finished.");
                                      }
                                      catch ( InterruptedException ex2 )
				      {
					    Thread.currentThread().interrupt();
				      }
				    }
				    betolt();
				    // You must close these even if you never use them!
				    p.getInputStream().close();
				    p.getOutputStream().close();
				    p.getErrorStream().close();
			    } catch (Exception ex1) {
				    System.err.println("Error running command clone_ini.");
			    }
			    clone_frame.setVisible(false);
		    }
	    }

	    public void cancelSelection() {
//		    System.out.println("Cancel button pressed.");
		    clone_frame.setVisible(false);
	    }
    };

}//end class controlpanel
