// This is the program fit-control which is part of the CMWP (Convolutional
// Multiple Whole Profile) fitting program package: http://www.renyi.hu/cmwp
//
// Copyright (C) G�bor Rib�rik, 1998-2009. Distributed under the terms of the
// CMWP Copyright file, see the file CMWP_COPYRIGHT for more details.
//
import javax.swing.JFrame;

class control {
    public static void main(String[] args) {
        JFrame window = new JFrame("CMWP fit control - "+args[0]+" - phase: "+args[1]);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setContentPane(new controlpanel(args[0]+"="+args[1]));
        window.pack();
        window.setVisible(true);
    }
}
