// This is the program fit-control which is part of the CMWP (Convolutional
// Multiple Whole Profile) fitting program package: http://www.renyi.hu/cmwp
//
// Copyright (C) G�bor Rib�rik and Tam�s Ung�r, 1998-2012. Distributed under
// the terms of the CMWP Copyright file, see the file CMWP_COPYRIGHT for more
// details.
//
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.StringTokenizer;

class controlpanel extends JPanel {
    String sample;
    private JCheckBox cryst_cub   = new JCheckBox();
    private JCheckBox cryst_hex   = new JCheckBox();
    private JCheckBox cryst_ort   = new JCheckBox();
    private JTextField lat_a_field   = new JTextField(4);
    private JTextField lat_b_field   = new JTextField(4);
    private JTextField lat_c_field   = new JTextField(4);
    private JTextField C_field   = new JTextField(4);
    private JTextField burgers_field   = new JTextField(4);
    private JTextField wavelength_field   = new JTextField(4);

    private JCheckBox NO_SIZE_EFFECT   = new JCheckBox();
    private JCheckBox SF_ELLIPSOIDAL   = new JCheckBox();

    private JCheckBox INDC   = new JCheckBox();
    private JCheckBox USE_STACKING   = new JCheckBox();

    private JCheckBox USE_WEIGHTS   = new JCheckBox();
    private JTextField WEIGHTING_ALGORITHM_field   = new JTextField(4);
    private JCheckBox peak_int_fit   = new JCheckBox();
    private JCheckBox peak_pos_fit   = new JCheckBox();
    private JCheckBox disable_coinc_g2   = new JCheckBox();

    private JCheckBox ENABLE_CONVOLUTION   = new JCheckBox();
    private JTextField INSTSRCDIR_field   = new JTextField(4);

    private JCheckBox fit_in_K = new JCheckBox();
    private JCheckBox CLONE2   = new JCheckBox();
    private JCheckBox CLONE3   = new JCheckBox();

    private JTextField IF_TH_FT_limit_field   = new JTextField(4);
    private JTextField PROF_CUT_field   = new JTextField(4);

    private JTextField N1_field   = new JTextField(4);
    private JTextField N2_field   = new JTextField(4);

    private JTextField minx_field   = new JTextField(4);
    private JTextField maxx_field   = new JTextField(4);

    private JTextField FIT_LIMIT_field   = new JTextField(4);
    private JTextField FIT_MAXITER_field   = new JTextField(4);

    private JTextField a1_field   = new JTextField(4);
    private JTextField a2_field   = new JTextField(4);
    private JTextField a3_field   = new JTextField(4);
    private JTextField a4_field   = new JTextField(4);
    private JTextField a5_field   = new JTextField(4);
    private JTextField eps_field   = new JTextField(4);
    private JTextField a_field   = new JTextField(4);
    private JCheckBox a_fix   = new JCheckBox();
    private JCheckBox a1_fix   = new JCheckBox();
    private JCheckBox a2_fix   = new JCheckBox();
    private JCheckBox a3_fix   = new JCheckBox();
    private JCheckBox a4_fix   = new JCheckBox();
    private JCheckBox a5_fix   = new JCheckBox();
    private JCheckBox eps_fix   = new JCheckBox();
    private JTextField scale_a   = new JTextField(4);

    private JTextField b_field   = new JTextField(4);
    private JCheckBox b_fix   = new JCheckBox();
    private JTextField scale_b   = new JTextField(4);

    private JTextField c_field   = new JTextField(4);
    private JCheckBox c_fix   = new JCheckBox();
    private JTextField scale_c   = new JTextField(4);

    private JTextField d_field   = new JTextField(4);
    private JCheckBox d_fix   = new JCheckBox();
    private JTextField scale_d   = new JTextField(4);

    private JTextField e_field   = new JTextField(4);
    private JCheckBox e_fix   = new JCheckBox();
    private JTextField scale_e   = new JTextField(4);

    private JCheckBox de_fix   = new JCheckBox();

    private JTextField st_pr_field   = new JTextField(4);
    private JCheckBox st_pr_fix   = new JCheckBox();
    private JTextField STACKING_field   = new JTextField(4);

    private JFrame instsrcdir_frame = new JFrame();
    private JFileChooser instsrcdir_chooser=new INSTSRCDIR_FileChooser();
    private boolean instsrcdir_chooser_opened=false;

    private JFrame stacking_frame = new JFrame();
    private JFileChooser stacking_chooser=new STACKING_FileChooser();
    private boolean stacking_chooser_opened=false;

    private JFrame clone_frame = new JFrame();
    private JFileChooser clone_chooser=new CLONE_FileChooser();
    private boolean clone_chooser_opened=false;

    private JTextField phase_num_field   = new JTextField(4);
    private JTextField edit_phase_field   = new JTextField(4);
    private JTextField fit_only_phase_field   = new JTextField(4);

    controlpanel(String samplename) {
        sample=samplename;
        //... Create button and add an action listener
        JButton runButton = new JButton("(Re)Start FIT");
        runButton.addActionListener(new runlistener());
        JButton stopButton = new JButton("Stop FIT");
        stopButton.addActionListener(new stoplistener());
        JButton updateButton = new JButton("Update Params");
        updateButton.addActionListener(new updatelistener());
        JButton viewpButton = new JButton("View Solutions");
        viewpButton.addActionListener(new viewplistener());
        JButton viewfButton = new JButton("View FIT");
        viewfButton.addActionListener(new viewflistener());
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(new exitlistener());
        JButton MKSplineButton = new JButton("Call MKSpline");
        MKSplineButton.addActionListener(new mksplinelistener());
        JButton MKSplineTwoButton = new JButton("Call MKSpline2");
        MKSplineTwoButton.addActionListener(new mksplinetwolistener());
        JButton IndexButton = new JButton("Index peaks");
        IndexButton.addActionListener(new make_peak_index_listener());
        JButton IndCButton = new JButton("Set individ. C values");
        IndCButton.addActionListener(new indClistener());
        JButton SaveIniButton = new JButton("Save INI files");
        SaveIniButton.addActionListener(new saveinilistener());
        JButton CloneIniButton = new JButton("Clone INI files");
        CloneIniButton.addActionListener(new cloneinilistener());
        JButton BrowseInstrButton = new JButton("Browse");
        BrowseInstrButton.addActionListener(new browseinstlistener());
        JButton BrowseStackingButton = new JButton("Browse");
        BrowseStackingButton.addActionListener(new browsestackinglistener());

        JButton EditPhaseButton = new JButton("Edit phase No:");
        EditPhaseButton.addActionListener(new editphaselistener());

        //... Set layout and add components.
        //this.setLayout(new FlowLayout());
	// Set the layout with 26 rows by 6 columns
	this.setLayout(new GridLayout(26,6));
        this.add(new JLabel("CUBIC: "));
        this.add(cryst_cub);
        this.add(new JLabel("HEXAGONAL: "));
        this.add(cryst_hex);
        this.add(new JLabel("ORTHOROMBIC: "));
        this.add(cryst_ort);
        this.add(new JLabel("lat_a (CUB|HEX|ORT) [nm]: "));
        this.add(lat_a_field);
        this.add(new JLabel("lat_b (ORT) [nm]: "));
        this.add(lat_b_field);
        this.add(new JLabel("lat_c (HEX|ORT) [nm]: "));
        this.add(lat_c_field);
        this.add(new JLabel("Burgers vector [nm]: "));
        this.add(burgers_field);
        this.add(new JLabel("Wavelength [nm]: "));
        this.add(wavelength_field);
        this.add(new JLabel("Ch00 or Chk0: "));
        this.add(C_field);

        this.add(new JLabel("Don't include size effect: "));
        this.add(NO_SIZE_EFFECT);
        this.add(new JLabel("Use ellipsoidal size func.: "));
        this.add(SF_ELLIPSOIDAL);
        this.add(new JLabel("Use individual C factors: "));
        this.add(INDC);

        this.add(new JLabel("Include St. Faults effect: "));
        this.add(USE_STACKING);
        this.add(new JLabel(""));
        this.add(new JLabel("stacking.dat file: "));
        this.add(STACKING_field);
        this.add(BrowseStackingButton);

        this.add(new JLabel("Use weights: "));
        this.add(USE_WEIGHTS);
        this.add(new JLabel("Weighting algorithm (1-4):"));
        this.add(WEIGHTING_ALGORITHM_field);
        this.add(new JLabel("Disable coinc. g^2 code: "));
        this.add(disable_coinc_g2);

        this.add(new JLabel("Use instrum. profiles: "));
        this.add(ENABLE_CONVOLUTION);
        this.add(new JLabel(""));
        this.add(new JLabel("Instrum. profiles dir.: "));
        this.add(INSTSRCDIR_field);
        this.add(BrowseInstrButton);
//      this.add(new JLabel(""));

        this.add(new JLabel("Fit peak int.: "));
        this.add(peak_int_fit);
        this.add(new JLabel(""));
        this.add(new JLabel("Fit peak pos.: "));
        this.add(peak_pos_fit);
        this.add(new JLabel(""));

        this.add(new JLabel("Fit in K instead of 2*theta: "));
        this.add(fit_in_K);

        this.add(new JLabel("Clone peak-index.dat file: "));
        this.add(CLONE2);
//      this.add(new JLabel(""));

        this.add(new JLabel("Clone bg-spline.dat file: "));
        this.add(CLONE3);
//      this.add(new JLabel(""));

        this.add(new JLabel("FT limit (if no instr. eff.): "));
        this.add(IF_TH_FT_limit_field);
        this.add(new JLabel(""));
        this.add(new JLabel("Profile cutting parameter: "));
        this.add(PROF_CUT_field);
        this.add(new JLabel(""));

        this.add(new JLabel("N1: "));
        this.add(N1_field);
        this.add(new JLabel(""));
        this.add(new JLabel("N2: "));
        this.add(N2_field);
        this.add(new JLabel(""));

        this.add(new JLabel("Min. 2*theta/K: "));
        this.add(minx_field);
        this.add(new JLabel(""));
        this.add(new JLabel("Max. 2*theta/K: "));
        this.add(maxx_field);
        this.add(new JLabel(""));

        this.add(new JLabel("FIT limit: "));
        this.add(FIT_LIMIT_field);
        this.add(new JLabel(""));
        this.add(new JLabel("FIT max. num. of iter.: "));
        this.add(FIT_MAXITER_field);
        this.add(new JLabel(""));

        this.add(new JLabel("init_a (CUB): "));
        this.add(a_field);
        this.add(new JLabel("init_a1 (HEX|ORT): "));
        this.add(a1_field);
        this.add(new JLabel("init_a2 (HEX|ORT): "));
        this.add(a2_field);
        this.add(new JLabel("a_fixed: "));
        this.add(a_fix);
        this.add(new JLabel("a1_fixed: "));
        this.add(a1_fix);
        this.add(new JLabel("a2_fixed: "));
        this.add(a2_fix);
        this.add(new JLabel("init_a3 (ORT): "));
        this.add(a3_field);
        this.add(new JLabel("init_a4 (ORT): "));
        this.add(a4_field);
        this.add(new JLabel("init_a5 (ORT): "));
        this.add(a5_field);
        this.add(new JLabel("a3_fixed: "));
        this.add(a3_fix);
        this.add(new JLabel("a4_fixed: "));
        this.add(a4_fix);
        this.add(new JLabel("a5_fixed: "));
        this.add(a5_fix);

        this.add(new JLabel("init_epsilon: "));
        this.add(eps_field);
        this.add(new JLabel("epsilon_fixed: "));
        this.add(eps_fix);

        this.add(new JLabel("scale_a: "));
        this.add(scale_a);

        this.add(new JLabel("init_b: "));
        this.add(b_field);
        this.add(new JLabel("b_fixed: "));
        this.add(b_fix);
        this.add(new JLabel("scale_b: "));
        this.add(scale_b);

        this.add(new JLabel("init_c: "));
        this.add(c_field);
        this.add(new JLabel("c_fixed: "));
        this.add(c_fix);
        this.add(new JLabel("scale_c: "));
        this.add(scale_c);

        this.add(new JLabel("init_d: "));
        this.add(d_field);
        this.add(new JLabel("d_fixed: "));
        this.add(d_fix);
        this.add(new JLabel("scale_d: "));
        this.add(scale_d);

        this.add(new JLabel("init_e: "));
        this.add(e_field);
        this.add(new JLabel("e_fixed: "));
        this.add(e_fix);
        this.add(new JLabel("scale_e: "));
        this.add(scale_e);

        this.add(new JLabel("init_st_pr: "));
        this.add(st_pr_field);
        this.add(new JLabel("st_pr_fixed: "));
        this.add(st_pr_fix);
        this.add(new JLabel("d*e_fixed: "));
        this.add(de_fix);

        this.add(new JLabel("Number of phases: "));
        this.add(phase_num_field);
        this.add(new JLabel("Fit ONLY phase No: "));
        this.add(fit_only_phase_field);
        this.add(EditPhaseButton);
        this.add(edit_phase_field);

        this.add(MKSplineButton);
        this.add(MKSplineTwoButton);
        this.add(IndexButton);
        this.add(IndCButton);
        this.add(CloneIniButton);
        this.add(SaveIniButton);

        this.add(runButton);
        this.add(stopButton);
        this.add(updateButton);
        this.add(viewpButton);
        this.add(viewfButton);
        this.add(exitButton);

	betolt();
    }

    private class runlistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./lib/kill_fit", sample} );
			try {
				p.waitFor();
				System.out.println("Kill_fit finished.");
			}
			catch ( InterruptedException ex2 )
			{
				Thread.currentThread().interrupt();
			}
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command kill_fit.");
		}

		elment();
    
		String datname=sample;
		try {
			File datf = new File(new File(sample+".dat").getCanonicalPath());
			if (datf.exists() == true && datf.isDirectory() == false) {
				datname=sample+".dat";
			}
		} catch (IOException exf ) {}

		System.out.println("Running: ./evaluate-int "+datname+" auto");

		//Example:
		//Runtime.getRuntime().exec( new String[]{ "/bin/sh", "-c", "echo $SHELL"} );

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "zsh", "-fc", "./evaluate-int "+datname+" auto"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running evaluate-int.");
		}
        }
    }

    private class stoplistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./lib/kill_fit", sample} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command kill_fit.");
		}
        }
    }

    private class updatelistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "./lib/update_fit_ini", sample+".dat"} );
			try {
				p.waitFor();
				System.out.println("Update finished.");
			}
			catch ( InterruptedException ex2 )
			{
				Thread.currentThread().interrupt();
			}
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command update_fit_ini.");
		}
		betolt();
        }
    }

    private class viewplistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "less", "+G", sample+".sol"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command less.");
		}
        }
    }

    private class viewflistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "gv", sample+".int.ps"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command gv.");
		}
        }
    }

    private class exitlistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		System.exit(0);
        }
    }

    private class make_peak_index_listener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./make_peak-index.sh", sample} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command make_peak-index.sh.");
		}
        }
    }

    private class mksplinelistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./mkspline", sample+".dat"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command mkspline.");
		}
        }
    }

    private class mksplinetwolistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./mkspline2", sample+".dat"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command mkspline2.");
		}
        }
    }

    private class indClistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./set_individ_C", sample+".dat"} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command set_individ_C.");
		}
        }
    }

    private class editphaselistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		Process p;

		try {
			p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./evaluate-control-phase", sample+".dat", edit_phase_field.getText()} );
			// You must close these even if you never use them!
			p.getInputStream().close();
			p.getOutputStream().close();
			p.getErrorStream().close();
		} catch (Exception ex1) {
			System.err.println("Error running command evaluate-control-phase");
		}
        }
    }

    private class saveinilistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
		System.out.println("Saving ini files.");
		elment();
        }
    }

    private class cloneinilistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

		try {
			clone_frame.setVisible(true);
			clone_frame.setSize(640,480);

//			clone_chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			clone_chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
//			clone_chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			clone_chooser.addChoosableFileFilter(new IniFilter());
			clone_chooser.setAcceptAllFileFilterUsed(false);
			if (clone_chooser_opened==false) {
				clone_chooser_opened=true;
				// get the current directory
				File f = new File(new File(".").getCanonicalPath());
				
				// Set the current directory
				clone_chooser.setCurrentDirectory(f);
			}
			clone_frame.add(clone_chooser);
			clone_chooser.rescanCurrentDirectory();
		} catch (Exception ex1) {
			System.err.println("Error creating new window.");
		}
        }
    }

    private class browseinstlistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

		if (ENABLE_CONVOLUTION.isSelected() == false)
			return;

		try {
			instsrcdir_frame.setVisible(true);
			instsrcdir_frame.setSize(640,480);

//			instsrcdir_chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
//			instsrcdir_chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			instsrcdir_chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			if (instsrcdir_chooser_opened==false) {
				instsrcdir_chooser_opened=true;
				// get the current directory
				if (INSTSRCDIR_field.getText().length()>0) {
					File f = new File(new File(INSTSRCDIR_field.getText()).getCanonicalPath());
    
					// Set the current directory
					instsrcdir_chooser.setCurrentDirectory(f);
				} else {
					File f = new File(new File(".").getCanonicalPath());
    
					// Set the current directory
					instsrcdir_chooser.setCurrentDirectory(f);
				}
			}
			instsrcdir_frame.add(instsrcdir_chooser);
			instsrcdir_chooser.rescanCurrentDirectory();
		} catch (Exception ex1) {
			System.err.println("Error creating new window.");
		}
        }
    }

    private class browsestackinglistener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

		if (USE_STACKING.isSelected() == false)
			return;

		try {
			stacking_frame.setVisible(true);
			stacking_frame.setSize(640,480);

//			stacking_chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			stacking_chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
//			stacking_chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			if (stacking_chooser_opened==false) {
				stacking_chooser_opened=true;
				// get the current directory
				if (STACKING_field.getText().length()>0) {
					File f = new File(new File(STACKING_field.getText()).getCanonicalPath());
    
					// Set the current directory
					stacking_chooser.setCurrentDirectory(f);
				} else {
					File f = new File(new File(".").getCanonicalPath());
    
					// Set the current directory
					stacking_chooser.setCurrentDirectory(f);
				}
			}
			stacking_frame.add(stacking_chooser);
			stacking_chooser.rescanCurrentDirectory();
		} catch (Exception ex1) {
			System.err.println("Error creating new window.");
		}
        }
    }

    private void elment() {
	Process p;

	elment_ini();
	elment_q_ini();
	elment_fit_ini();

	if (phase_num_field.getText().length()>0) {
		try {
                        p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "zsh", "-fc", "./create-multi-phase-ini.sh "+sample+" "+phase_num_field.getText()} );
                        // You must close these even if you never use them!
                        p.getInputStream().close();
                        p.getOutputStream().close();
                        p.getErrorStream().close();
                } catch (Exception ex1) {
                        System.err.println("Error running create-multi-phase-ini.sh.");
                }

	}
    }

    private void betolt() {
	betolt_ini();
	betolt_q_ini();
	betolt_fit_ini();
    }

    private void betolt_ini() {
	cryst_cub.setSelected(false);
	cryst_hex.setSelected(false);
	cryst_ort.setSelected(false);
	boolean lb_set=false;
	boolean lc_set=false;
        try {
          BufferedReader r = new BufferedReader(
                               new FileReader(sample+".dat.ini") );
          String line;
          while( (line = r.readLine()) != null ) {
		  StringTokenizer st = new StringTokenizer(line);
		  while ( st.hasMoreTokens() ) {
			  String st1=st.nextToken();
			  String[] st2=st1.split("=", 2);
			  
//			  System.out.println(st2[0]);
//			  System.out.println(st2[1]);
			  if (st2[0].matches("la"))
				  lat_a_field.setText(st2[1]);
			  if (st2[0].matches("lb")) {
				  lat_b_field.setText(st2[1]);
				  lb_set=true;
			  }
			  if (st2[0].matches("lc")) {
				  lat_c_field.setText(st2[1]);
				  lc_set=true;
			  }
			  if (st2[0].matches("bb"))
				  burgers_field.setText(st2[1]);
			  if (st2[0].matches("C0"))
				  C_field.setText(st2[1]);
			  if (st2[0].matches("wavelength"))
				  wavelength_field.setText(st2[1]);
		  }
	  }
          r.close();
        } catch (IOException e ) { System.err.println("ERROR reading file."); }
	if (lc_set==true) {
	    if (lb_set==true) {
		cryst_ort.setSelected(true);
	    } else {
		cryst_hex.setSelected(true);
	    }
	} else {
	    cryst_cub.setSelected(true);
	}
    }

    private void elment_ini() {
	    String endl = System.getProperty("line.separator");
	    try {
		    PrintWriter w = new PrintWriter(new FileWriter(sample+".dat.ini"));
		    w.print("la="+lat_a_field.getText()+endl);
		    if (cryst_ort.isSelected()) {
			w.print("lb="+lat_b_field.getText()+endl);
		    }
		    if (cryst_hex.isSelected() || cryst_ort.isSelected()) {
			w.print("lc="+lat_c_field.getText()+endl);
		    }
		    w.print("bb="+burgers_field.getText()+endl);
		    w.print("C0="+C_field.getText()+endl);
		    w.print("wavelength="+wavelength_field.getText()+endl);
		    w.close();
	    } catch (IOException e ) { System.err.println("ERROR writing file."); }
    }

    private void betolt_q_ini() {
	NO_SIZE_EFFECT.setSelected(false);
	SF_ELLIPSOIDAL.setSelected(false);
	INDC.setSelected(false);
	USE_STACKING.setSelected(false);
	USE_WEIGHTS.setSelected(false);
	peak_int_fit.setSelected(false);
	peak_pos_fit.setSelected(false);
	fit_in_K.setSelected(false);
	disable_coinc_g2.setSelected(false);
	ENABLE_CONVOLUTION.setSelected(false);
	CLONE2.setSelected(false);
	CLONE3.setSelected(false);
        try {
          BufferedReader r = new BufferedReader(
                               new FileReader(sample+".dat.q.ini") );
          String line;
          while( (line = r.readLine()) != null ) {
		  StringTokenizer st = new StringTokenizer(line);
		  while ( st.hasMoreTokens() ) {
			  String st1=st.nextToken();
			  String[] st2=st1.split("=", 2);
			  
//			  System.out.println(st2[0]);
//			  System.out.println(st2[1]);
			  if (st2[0].matches("NO_SIZE_EFFECT") && st2[1].matches("y"))
				  NO_SIZE_EFFECT.setSelected(true);
			  if (st2[0].matches("SF_ELLIPSOIDAL") && st2[1].matches("y"))
				  SF_ELLIPSOIDAL.setSelected(true);
			  if (st2[0].matches("INDC") && st2[1].matches("y"))
				  INDC.setSelected(true);
			  if (st2[0].matches("USE_STACKING") && st2[1].matches("y"))
				  USE_STACKING.setSelected(true);
			  if (st2[0].matches("STACKING_DAT"))
				  STACKING_field.setText(st2[1]);
			  if (st2[0].matches("USE_WEIGHTS") && st2[1].matches("y"))
				  USE_WEIGHTS.setSelected(true);
			  if (st2[0].matches("WEIGHTING_ALGORITHM"))
				  WEIGHTING_ALGORITHM_field.setText(st2[1]);
			  if (st2[0].matches("peak_int_fit") && st2[1].matches("y"))
				  peak_int_fit.setSelected(true);
			  if (st2[0].matches("peak_pos_fit") && st2[1].matches("y"))
				  peak_pos_fit.setSelected(true);
			  if (st2[0].matches("fit_in_K") && st2[1].matches("y"))
				  fit_in_K.setSelected(true);
			  if (st2[0].matches("DISABLE_COINC_G2") && st2[1].matches("y"))
				  disable_coinc_g2.setSelected(true);
			  if (st2[0].matches("ENABLE_CONVOLUTION") && st2[1].matches("y"))
				  ENABLE_CONVOLUTION.setSelected(true);
			  if (st2[0].matches("INSTSRCDIR"))
				  INSTSRCDIR_field.setText(st2[1]);
			  if (st2[0].matches("IF_TH_FT_limit"))
				  IF_TH_FT_limit_field.setText(st2[1]);
			  if (st2[0].matches("PROF_CUT"))
				  PROF_CUT_field.setText(st2[1]);
			  if (st2[0].matches("N1"))
				  N1_field.setText(st2[1]);
			  if (st2[0].matches("N2"))
				  N2_field.setText(st2[1]);
			  if (st2[0].matches("minx"))
				  minx_field.setText(st2[1]);
			  if (st2[0].matches("maxx"))
				  maxx_field.setText(st2[1]);
			  if (st2[0].matches("FIT_LIMIT"))
				  FIT_LIMIT_field.setText(st2[1]);
			  if (st2[0].matches("FIT_MAXITER"))
				  FIT_MAXITER_field.setText(st2[1]);
			  if (st2[0].matches("NUMBER_OF_PHASES"))
				  phase_num_field.setText(st2[1]);
			  if (st2[0].matches("FIT_ONLY_PHASE"))
				  fit_only_phase_field.setText(st2[1]);
		  }
	  }
          r.close();
        } catch (IOException e ) { System.err.println("ERROR reading file."); }
    }

    private void elment_q_ini() {
	    String endl = System.getProperty("line.separator");
	    try {
		    PrintWriter w = new PrintWriter(new FileWriter(sample+".dat.q.ini"));
		    w.print("USE_SPLINE=y"+endl);
		    if (NO_SIZE_EFFECT.isSelected())
			w.print("NO_SIZE_EFFECT=y"+endl);
		    else
			w.print("NO_SIZE_EFFECT=n"+endl);
		    if (SF_ELLIPSOIDAL.isSelected())
			w.print("SF_ELLIPSOIDAL=y"+endl);
		    else
			w.print("SF_ELLIPSOIDAL=n"+endl);
		    if (INDC.isSelected())
			w.print("INDC=y"+endl);
		    else
			w.print("INDC=n"+endl);
		    if (USE_STACKING.isSelected()) {
			w.print("USE_STACKING=y"+endl);
			if (STACKING_field.getText().length()>0) {
				w.print("STACKING_DAT="+STACKING_field.getText()+endl);
			}
		    } else
			w.print("USE_STACKING=n"+endl);
		    if (USE_WEIGHTS.isSelected())
			w.print("USE_WEIGHTS=y"+endl);
		    else
			w.print("USE_WEIGHTS=n"+endl);
		    if (WEIGHTING_ALGORITHM_field.getText().length()>0) {
			w.print("WEIGHTING_ALGORITHM="+WEIGHTING_ALGORITHM_field.getText()+endl); }
		    else {
			w.print("WEIGHTING_ALGORITHM=1"+endl);
		    }
		    if (peak_int_fit.isSelected())
			w.print("peak_int_fit=y"+endl);
		    else
			w.print("peak_int_fit=n"+endl);
		    if (peak_pos_fit.isSelected())
			w.print("peak_pos_fit=y"+endl);
		    else
			w.print("peak_pos_fit=n"+endl);
		    if (fit_in_K.isSelected())
			w.print("fit_in_K=y"+endl);
		    else
			w.print("fit_in_K=n"+endl);
		    if (disable_coinc_g2.isSelected())
			w.print("DISABLE_COINC_G2=y"+endl);
		    else
			w.print("DISABLE_COINC_G2=n"+endl);
		    if (ENABLE_CONVOLUTION.isSelected()) {
			w.print("ENABLE_CONVOLUTION=y"+endl);
			if (INSTSRCDIR_field.getText().length()>0) {
				w.print("INSTSRCDIR="+INSTSRCDIR_field.getText()+endl);
			}
		    } else {
			w.print("ENABLE_CONVOLUTION=n"+endl);
			w.print("IF_TH_FT_limit="+IF_TH_FT_limit_field.getText()+endl);
		    }
		    w.print("PROF_CUT="+PROF_CUT_field.getText()+endl);
		    w.print("N1="+N1_field.getText()+endl);
		    w.print("N2="+N2_field.getText()+endl);
		    w.print("minx="+minx_field.getText()+endl);
		    w.print("maxx="+maxx_field.getText()+endl);
		    w.print("FIT_LIMIT="+FIT_LIMIT_field.getText()+endl);
		    w.print("FIT_MAXITER="+FIT_MAXITER_field.getText()+endl);
		    if (phase_num_field.getText().length()>0) {
			    w.print("NUMBER_OF_PHASES="+phase_num_field.getText()+endl);
		    }
		    if (fit_only_phase_field.getText().length()>0) {
			    w.print("FIT_ONLY_PHASE="+fit_only_phase_field.getText()+endl);
		    }
		    w.close();
	    } catch (IOException e ) { System.err.println("ERROR writing file."); }
    };

    private void betolt_fit_ini() {
	a_fix.setSelected(false);
	a1_fix.setSelected(false);
	a2_fix.setSelected(false);
	a3_fix.setSelected(false);
	a4_fix.setSelected(false);
	a5_fix.setSelected(false);
	b_fix.setSelected(false);
	c_fix.setSelected(false);
	d_fix.setSelected(false);
	e_fix.setSelected(false);
	de_fix.setSelected(false);
	eps_fix.setSelected(false);
	st_pr_fix.setSelected(false);
        try {
          BufferedReader r = new BufferedReader(
                               new FileReader(sample+".dat.fit.ini") );
          String line;
          while( (line = r.readLine()) != null ) {
		  StringTokenizer st = new StringTokenizer(line);
		  while ( st.hasMoreTokens() ) {
			  String st1=st.nextToken();
			  String[] st2=st1.split("=", 2);
			  
//			  System.out.println(st2[0]);
//			  System.out.println(st2[1]);
			  if (st2[0].matches("init_a"))
				  a_field.setText(st2[1]);
			  if (st2[0].matches("init_a1"))
				  a1_field.setText(st2[1]);
			  if (st2[0].matches("init_a2"))
				  a2_field.setText(st2[1]);
			  if (st2[0].matches("init_a3"))
				  a3_field.setText(st2[1]);
			  if (st2[0].matches("init_a4"))
				  a4_field.setText(st2[1]);
			  if (st2[0].matches("init_a5"))
				  a5_field.setText(st2[1]);
			  if (st2[0].matches("init_b"))
				  b_field.setText(st2[1]);
			  if (st2[0].matches("init_c"))
				  c_field.setText(st2[1]);
			  if (st2[0].matches("init_d"))
				  d_field.setText(st2[1]);
			  if (st2[0].matches("init_e"))
				  e_field.setText(st2[1]);
			  if (st2[0].matches("init_epsilon"))
				  eps_field.setText(st2[1]);
			  if (st2[0].matches("init_st_pr"))
				  st_pr_field.setText(st2[1]);
			  if (st2[0].matches("scale_a"))
				  scale_a.setText(st2[1]);
			  if (st2[0].matches("scale_b"))
				  scale_b.setText(st2[1]);
			  if (st2[0].matches("scale_c"))
				  scale_c.setText(st2[1]);
			  if (st2[0].matches("scale_d"))
				  scale_d.setText(st2[1]);
			  if (st2[0].matches("scale_e"))
				  scale_e.setText(st2[1]);
			  if (st2[0].matches("a_fixed"))
				  a_fix.setSelected(true);
			  if (st2[0].matches("a1_fixed"))
				  a1_fix.setSelected(true);
			  if (st2[0].matches("a2_fixed"))
				  a2_fix.setSelected(true);
			  if (st2[0].matches("a3_fixed"))
				  a3_fix.setSelected(true);
			  if (st2[0].matches("a4_fixed"))
				  a4_fix.setSelected(true);
			  if (st2[0].matches("a5_fixed"))
				  a5_fix.setSelected(true);
			  if (st2[0].matches("b_fixed"))
				  b_fix.setSelected(true);
			  if (st2[0].matches("c_fixed"))
				  c_fix.setSelected(true);
			  if (st2[0].matches("d_fixed"))
				  d_fix.setSelected(true);
			  if (st2[0].matches("e_fixed"))
				  e_fix.setSelected(true);
			  if (st2[0].matches("de_fixed"))
				  de_fix.setSelected(true);
			  if (st2[0].matches("eps_fixed"))
				  eps_fix.setSelected(true);
			  if (st2[0].matches("st_pr_fixed"))
				  st_pr_fix.setSelected(true);
		  }
	  }
          r.close();
        } catch (IOException e ) { System.err.println("ERROR reading file."); }
    };

    private void elment_fit_ini() {
	    Process p;
	    String endl = System.getProperty("line.separator");
	    try {
		    PrintWriter w = new PrintWriter(new FileWriter(sample+".dat.fit.ini"));
		    if (a_field.getText().length()>0) {
			    w.print("init_a="+a_field.getText()+endl);
		    } else {
			    w.print("init_a=1.0"+endl);
		    }
		    if (a1_field.getText().length()>0) {
			    w.print("init_a1="+a1_field.getText()+endl);
		    } else {
			    w.print("init_a1=1.0"+endl);
		    }
		    if (a2_field.getText().length()>0) {
			    w.print("init_a2="+a2_field.getText()+endl);
		    } else {
			    w.print("init_a2=1.0"+endl);
		    }
		    if (a3_field.getText().length()>0) {
			    w.print("init_a3="+a3_field.getText()+endl);
		    } else {
			    w.print("init_a3=1.0"+endl);
		    }
		    if (a4_field.getText().length()>0) {
			    w.print("init_a4="+a4_field.getText()+endl);
		    } else {
			    w.print("init_a4=1.0"+endl);
		    }
		    if (a5_field.getText().length()>0) {
			    w.print("init_a5="+a5_field.getText()+endl);
		    } else {
			    w.print("init_a5=1.0"+endl);
		    }
		    if (b_field.getText().length()>0) {
			    w.print("init_b="+b_field.getText()+endl);
		    } else {
			    w.print("init_b=1.0"+endl);
		    }
		    if (c_field.getText().length()>0) {
			    w.print("init_c="+c_field.getText()+endl);
		    } else {
			    w.print("init_c=1.0"+endl);
		    }
		    if (d_field.getText().length()>0) {
			    w.print("init_d="+d_field.getText()+endl);
		    } else {
			    w.print("init_d=1.0"+endl);
		    }
		    if (e_field.getText().length()>0) {
			    w.print("init_e="+e_field.getText()+endl);
		    } else {
			    w.print("init_e=1.0"+endl);
		    }
		    if (eps_field.getText().length()>0) {
			    w.print("init_epsilon="+eps_field.getText()+endl);
		    } else {
			    w.print("init_epsilon=1.0"+endl);
		    }
		    if (USE_STACKING.isSelected()) {
			if (st_pr_field.getText().length()>0) {
				w.print("init_st_pr="+st_pr_field.getText()+endl);
			} else {
				w.print("init_st_pr=1.0"+endl);
			}
		    }
		    if (a_fix.isSelected())
			    w.print("a_fixed=\"y\""+endl);
		    if (a1_fix.isSelected())
			    w.print("a1_fixed=\"y\""+endl);
		    if (a2_fix.isSelected())
			    w.print("a2_fixed=\"y\""+endl);
		    if (a3_fix.isSelected())
			    w.print("a3_fixed=\"y\""+endl);
		    if (a4_fix.isSelected())
			    w.print("a4_fixed=\"y\""+endl);
		    if (a5_fix.isSelected())
			    w.print("a5_fixed=\"y\""+endl);
		    if (b_fix.isSelected())
			    w.print("b_fixed=\"y\""+endl);
		    if (c_fix.isSelected())
			    w.print("c_fixed=\"y\""+endl);
		    if (d_fix.isSelected())
			    w.print("d_fixed=\"y\""+endl);
		    if (e_fix.isSelected())
			    w.print("e_fixed=\"y\""+endl);
		    if (de_fix.isSelected())
			    w.print("de_fixed=\"y\""+endl);
		    if (eps_fix.isSelected())
			    w.print("epsilon_fixed=\"y\""+endl);
		    if (st_pr_fix.isSelected())
			    w.print("st_pr_fixed=\"y\""+endl);
		    if (scale_a.getText().length()>0) {
			    w.print("scale_a="+scale_a.getText()+endl);
		    } else {
			    w.print("scale_a=1.0"+endl);
		    }
		    if (scale_b.getText().length()>0) {
			    w.print("scale_b="+scale_b.getText()+endl);
		    } else {
			    w.print("scale_b=1.0"+endl);
		    }
		    if (scale_c.getText().length()>0) {
			    w.print("scale_c="+scale_c.getText()+endl);
		    } else {
			    w.print("scale_c=1.0"+endl);
		    }
		    if (scale_d.getText().length()>0) {
			    w.print("scale_d="+scale_d.getText()+endl);
		    } else {
			    w.print("scale_d=1.0"+endl);
		    }
		    if (scale_e.getText().length()>0) {
			    w.print("scale_e="+scale_e.getText()+endl);
		    } else {
			    w.print("scale_e=1.0"+endl);
		    }
		    w.close();

	    } catch (IOException e ) { System.err.println("ERROR writing file."); }
    };

    class INSTSRCDIR_FileChooser extends JFileChooser {
    // A leiras rola itt van:
    // http://java.sun.com/docs/books/tutorial/uiswing/components/filechooser.html
	    public void approveSelection() {
		    File f=getSelectedFile();

//		    String name=getName(f);
		    String name=f.getPath();
//		    System.out.println("Open button pressed, file name: "+name);
		    if (f.exists() == true && f.isDirectory() == true) {
			    try {
				    File cwdf = new File(new File(".").getCanonicalPath());
				    String cwd=cwdf.getPath();

				    int cwdlength=(int) cwd.length()+1;

				    if (name.startsWith(cwd)) {
					    INSTSRCDIR_field.setText(name.substring(cwdlength));
				    } else {
					    INSTSRCDIR_field.setText(name);
				    }
			    } catch (IOException e ) { System.err.println("ERROR getting path name of current directory."); }
			    instsrcdir_frame.setVisible(false);
		    }
	    }

	    public void cancelSelection() {
//		    System.out.println("Cancel button pressed.");
		    instsrcdir_frame.setVisible(false);
	    }
    };

    class STACKING_FileChooser extends JFileChooser {
    // A leiras rola itt van:
    // http://java.sun.com/docs/books/tutorial/uiswing/components/filechooser.html
	    public void approveSelection() {
		    File f=getSelectedFile();

//		    String name=getName(f);
		    String name=f.getPath();
//		    System.out.println("Open button pressed, file name: "+name);
		    if (f.exists() == true && f.isDirectory() == false) {
			    try {
				    File cwdf = new File(new File(".").getCanonicalPath());
				    String cwd=cwdf.getPath();

				    int cwdlength=(int) cwd.length()+1;

				    if (name.startsWith(cwd)) {
					    STACKING_field.setText(name.substring(cwdlength));
				    } else {
					    STACKING_field.setText(name);
				    }
			    } catch (IOException e ) { System.err.println("ERROR getting path name of current directory."); }
			    stacking_frame.setVisible(false);
		    }
	    }

	    public void cancelSelection() {
//		    System.out.println("Cancel button pressed.");
		    stacking_frame.setVisible(false);
	    }
    };


    class CLONE_FileChooser extends JFileChooser {
	    Process p;

	    public void approveSelection() {
		    File f=getSelectedFile();

//		    String name=getName(f);
		    String name=f.getPath();
//		    System.out.println("Open button pressed, file name: "+name);
		    if (f.exists() == true && f.isDirectory() == false) {
			    try {
				    p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./lib/clone_ini", name, sample} );
				    try {
					    p.waitFor();
					    System.out.println("clone_ini finished.");
				    }
				    catch ( InterruptedException ex2 )
				    {
					    Thread.currentThread().interrupt();
				    }
				    if (CLONE2.isSelected()) {
      				      p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./lib/clone_ini2", name, sample} );
      				      try {
					    p.waitFor();
					    System.out.println("clone_ini2 finished.");
                                      }
                                      catch ( InterruptedException ex2 )
				      {
					    Thread.currentThread().interrupt();
				      }
				    }
				    if (CLONE3.isSelected()) {
      				      p=Runtime.getRuntime().exec( new String[]{ "xterm", "-e", "./lib/clone_ini3", name, sample} );
      				      try {
					    p.waitFor();
					    System.out.println("clone_ini3 finished.");
                                      }
                                      catch ( InterruptedException ex2 )
				      {
					    Thread.currentThread().interrupt();
				      }
				    }
				    betolt();
				    // You must close these even if you never use them!
				    p.getInputStream().close();
				    p.getOutputStream().close();
				    p.getErrorStream().close();
			    } catch (Exception ex1) {
				    System.err.println("Error running command clone_ini.");
			    }
			    clone_frame.setVisible(false);
		    }
	    }

	    public void cancelSelection() {
//		    System.out.println("Cancel button pressed.");
		    clone_frame.setVisible(false);
	    }
    };

}//end class controlpanel
