#! /usr/local/bin/zsh -f
PATH="/home/ribarik/CMWP-121207/progs/bin:/home/ribarik/CMWP-121207/progs/jre1.6.0_12/bin:/home/ribarik/CMWP-121207/progs/libexec/gnuplot/4.2:/home/ribarik/bin.scripts:/home/ribarik/bin.sun4m:/home/ribarik/bin:/usr/local/tool:/usr/local/bin:/usr/local/sbin:/usr/local/samba/bin:/usr/local/bin/TeX:/usr/local/ssl/bin:/usr/local/etc:/usr/local/nmh/bin:/usr/etc:/etc:/usr/hosts:/usr/openwin/bin:/usr/openwin/demo/:/usr/bin/X11:/usr/ucb:/usr/bin:/usr/sbin:/sbin:/bin:/usr/games:/usr/dt/bin:/usr/ccs/bin:/usr/java1.1/bin:/opt/SUNWspro/bin:/opt/SUNWste/bin/:/usr/sadm/bin:/usr/xpg4/bin:/usr/proc/bin:/usr/vmsys/bin:/opt/SUNWrtvc/bin:./bin:.:/usr/local/bin:/usr/bin:/bin:/usr/share/lib:/usr/ccs/bin:/usr/xpg4/bin:$PATH"
# Copyright (C) G�bor Rib�rik, 1998-2009. All rights reserved.
# For permission to use, copy, modify this program or any of its components,
# see the file CMWP_COPYRIGHT.

export LC_ALL="POSIX"
if [[ -z $1 ]]
then
    echo "Usage: $0 SAMPLENAME NUMBER_OF_PHASES"
    exit 1
fi
grep -v '_[0-9][0-9]*=' $1.dat.ini >$1.dat.ini-new
cat $1.dat.ini-new >$1.dat.ini
rm -f $1.dat.ini-new
grep -v '_[0-9][0-9]*=' $1.dat.fit.ini >$1.dat.fit.ini-new
cat $1.dat.fit.ini-new >$1.dat.fit.ini
rm -f $1.dat.fit.ini-new
let n=1
repeat $[$2-1]
do
	if [[ ! -e $1.dat.ini.ph$n || ! -e $1.dat.fit.ini.ph$n ]]
	then
	    echo "Error, ini files for phase $n not found."
	    exit 1
	else
	    cat $1.dat.ini.ph$n >>$1.dat.ini
	    cat $1.dat.fit.ini.ph$n >>$1.dat.fit.ini
	fi
	let n+=1
done
