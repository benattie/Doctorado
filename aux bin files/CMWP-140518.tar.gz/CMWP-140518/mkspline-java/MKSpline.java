// This is the program MKSpline which is part of the CMWP (Convolutional
// Multiple Whole Profile) fitting program package: http://www.renyi.hu/cmwp
//
// Copyright (C) G�bor Rib�rik, 1998-2009. Distributed under the terms of the
// CMWP Copyright file, see the file CMWP_COPYRIGHT for more details.
//
// Credits:
// It uses code from the freely distributed Lagrange.java program found at
// http://www.ibiblio.org/e-notes/Splines/Lagrange.htm
// Interactive 2D Lagrange splines,  Evgeny Demidov 22 June 2001
//
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.StringTokenizer;

public class MKSpline extends JPanel
  implements MouseMotionListener{
Image buffImage;          Graphics buffGraphics;
JLabel xscale = new JLabel("X scale:");
JTextField xmin_Field   = new JTextField(4);
JLabel xhyphen = new JLabel("-");
JTextField xmax_Field   = new JTextField(4);
JLabel yscale = new JLabel("Y scale:");
JTextField ymin_Field   = new JTextField(4);
JLabel yhyphen = new JLabel("-");
JTextField ymax_Field   = new JTextField(4);
JButton rescale = new JButton("ReScale");
JButton addnew = new JButton("Add new point");
JLabel LogLabel = new JLabel("Logscale:  ON");
JButton toggleLog = new JButton("Toggle LogScale");
boolean logscale=true;
JButton exitButton = new JButton("Save & Exit");
int n = 3, n1,  w,h,h1,w2, dat_n, bg_dat_n;
double[] Px,Py, spl_x, spl_y, dat_x, dat_y, bg_dat_x, bg_dat_y;
double minx;
double maxx;
double miny;
double maxy;
String lineend = System.getProperty("line.separator");

public double bgp_spline(double x)
{
	double f=0, k1=0, k2=0, x0, y0, x1, y1, x2, y2, x3, y3, dx, dy;
	double a=0, b=0, c=0, d=0;
	int i=0, ind=0, maxn=n-2;

	if (x<=Px[0])
		ind=0;
	else if (x>=Px[maxn])
		ind=maxn;
	else {
		for (i=0; i<maxn; i++)
			if (Px[i]<=x && x<Px[i+1]) {
				ind=i;
				break;
			}
	}
	if (ind==0) {
		x1=Px[0];
		y1=Py[0];
		x2=Px[1];
		y2=Py[1];
		x3=Px[2];
		y3=Py[2];
		k2=(y3-y1)/(x3-x1);
		k1=(3*(y2-y1)/(x2-x1)-k2)/2;
	} else if (ind==maxn) {
		x0=Px[maxn-1];
		y0=Py[maxn-1];
		x1=Px[maxn];
		y1=Py[maxn];
		x2=Px[maxn+1];
		y2=Py[maxn+1];
		k1=(y2-y0)/(x2-x0);
		k2=(3*(y2-y1)/(x2-x1)-k1)/2;
	} else {
		x0=Px[ind-1];
		y0=Py[ind-1];
		x1=Px[ind];
		y1=Py[ind];
		x2=Px[ind+1];
		y2=Py[ind+1];
		x3=Px[ind+2];
		y3=Py[ind+2];
		k1=(y2-y0)/(x2-x0);
		k2=(y3-y1)/(x3-x1);
	}

	dx = x2 - x1;
	dy = y2 - y1;

	a = ((k1 + k2) - 2*dy/dx)/(dx*dx);
	b = ((k2 - k1)/dx - 3*(x1 + x2)*a)/2;
	c = k1 - (3*x1*a + 2*b)*x1;
	d = y1 - ((x1*a + b)*x1 + c)*x1;

	f=((a*x+b)*x+c)*x+d;
	return f;
}


static Frame f = new JFrame();
static MKSpline mksp = new MKSpline();

public static void main(String[] args) {

  f.addWindowListener(new java.awt.event.WindowAdapter() {
       public void windowClosing(java.awt.event.WindowEvent e) {
       System.exit(0);
       };
     });
  f.setLayout(new BorderLayout());

  mksp.setSize(1024,768);
  f.add(mksp);
  f.pack();
  mksp.init(args[0]);
  f.setSize(1024,768 + 20);
  f.show();

}

public void init(String samplename) {

//  System.out.println("Samplename: "+samplename);

//  w = Integer.parseInt(getParameter("width"));
//  h = Integer.parseInt(getParameter("height"))-40;  h1 = h-1; w2 = w;
  w = 1024;
  h = 768-40;  h1 = h-1; w2 = w;
  int nmax=1024;
  spl_x = new double[nmax];  spl_y = new double[nmax];
  int datmax=262144;
  dat_x = new double[datmax];  dat_y = new double[datmax];
  Px = new double[nmax];  Py = new double[nmax];

    try {
      BufferedReader dat_in = new BufferedReader(
                               new FileReader(samplename+".dat") );

      String line;
      dat_n = 0;
      while ((line = dat_in.readLine()) != null) {

            StringTokenizer st = new StringTokenizer(line);
            dat_x[dat_n] = Double.valueOf(st.nextToken()).doubleValue();
            dat_y[dat_n] = Double.valueOf(st.nextToken()).doubleValue();
            dat_n+=1;

      }
    
      dat_in.close();
    } catch (IOException e) {
      e.printStackTrace();
    }

//  System.out.println("Read: "+dat_n+" data points.");

  minx=dat_x[0];
  maxx=dat_x[0];
  miny=dat_y[0];
  maxy=dat_y[0];
  for (int i = 0; i < dat_n; i++){
    if ( dat_x[i] < minx ) { minx=dat_x[i]; }
    if ( dat_y[i] < miny ) { miny=dat_y[i]; }
    if ( dat_x[i] > maxx ) { maxx=dat_x[i]; }
    if ( dat_y[i] > maxy ) { maxy=dat_y[i]; }
  }

//  System.out.println("Data: minx: "+minx+", maxx:"+maxx);
//  System.out.println("Data: miny: "+miny+", maxy:"+maxy);

    try {

      BufferedReader spl_in = new BufferedReader(
                               new FileReader(samplename+".bg-spline.dat") );

      String line;
      n = 0;
      while ((line = spl_in.readLine()) != null) {

            StringTokenizer st = new StringTokenizer(line);
            spl_x[n] = Double.valueOf(st.nextToken()).doubleValue();
            spl_y[n] = Double.valueOf(st.nextToken()).doubleValue();
            n+=1;

      }
    
      spl_in.close();
    } catch (IOException e) {
      e.printStackTrace();
    }

  for (int i = 0; i < n; i++){
    if ( spl_x[i] < minx ) { minx=spl_x[i]; }
    if ( spl_y[i] < miny ) { miny=spl_y[i]; }
    if ( spl_x[i] > maxx ) { maxx=spl_x[i]; }
    if ( spl_y[i] > maxy ) { maxy=spl_y[i]; }
  }

//  System.out.println("Spline: minx: "+minx+", maxx:"+maxx);
//  System.out.println("Spline: miny: "+miny+", maxy:"+maxy);

  // Extend y scale - HACK!!!
  if (miny>0) {miny*=0.9;} else {miny*=1.2;}
  if (maxy>0) {maxy*=1.2;} else {maxy*=0.9;}

  minx-=0.015*Math.abs(maxx-minx);
  maxx+=0.015*Math.abs(maxx-minx);

//  System.out.println("Scale: minx: "+minx+", maxx:"+maxx);
//  System.out.println("Scale: miny: "+miny+", maxy:"+maxy);

  for (int i = 0; i < n; i++){
    Px[i] = spl_x[i];
    Py[i] = spl_y[i];
  }

//  System.out.println("Initial base points:");
//  print_base();
  buffImage = createImage(w, h);
  buffGraphics = buffImage.getGraphics();
  setBackground(Color.white);
  buffGraphics.clearRect(0,0, w, h);
  addMouseMotionListener(this);
  drawDATA();
  drawSpline();


JPanel gombok = new JPanel();
gombok.setLayout(new FlowLayout());

    gombok.add(xscale);
    gombok.add(xmin_Field);
    xmin_Field.setText(""+minx+"");
    gombok.add(xhyphen);
    gombok.add(xmax_Field);
    xmax_Field.setText(""+maxx+"");
    gombok.add(yscale);
    gombok.add(ymin_Field);
    ymin_Field.setText(""+miny+"");
    gombok.add(yhyphen);
    gombok.add(ymax_Field);
    ymax_Field.setText(""+maxy+"");
    gombok.add(rescale);
    LogLabel.setText("Logscale:  ON");
    LogLabel.resize (LogLabel.preferredSize());
    gombok.add(LogLabel);
    gombok.add(toggleLog);
    gombok.add(addnew);
    gombok.add(exitButton);

    f.add(gombok,BorderLayout.SOUTH);
//  content_pane.validate();
//  content_pane.setVisible(true);

    rescale.addActionListener( new ActionListener(){
      public void actionPerformed( ActionEvent ae ){
	      StringTokenizer st = new StringTokenizer(xmin_Field.getText());
	      minx=Double.valueOf(st.nextToken()).doubleValue();
	      st = new StringTokenizer(xmax_Field.getText());
	      maxx=Double.valueOf(st.nextToken()).doubleValue();
	      st = new StringTokenizer(ymin_Field.getText());
	      miny=Double.valueOf(st.nextToken()).doubleValue();
	      st = new StringTokenizer(ymax_Field.getText());
	      maxy=Double.valueOf(st.nextToken()).doubleValue();
	      drawDATA();
	      drawSpline();
	      repaint();
      }
    } );
    addnew.addActionListener( new ActionListener(){
      public void actionPerformed( ActionEvent ae ){
        add_new();
      }
    } );
    toggleLog.addActionListener( new ActionListener(){
      public void actionPerformed( ActionEvent ae ){
	      if (logscale) { logscale=false;
	      LogLabel.setText("Logscale: OFF");
	      LogLabel.resize (LogLabel.preferredSize()); }
	      else { logscale=true; 
	      LogLabel.setText("Logscale:  ON");
	      LogLabel.resize (LogLabel.preferredSize()); }
	      drawDATA();
	      drawSpline();
	      repaint();
      }
    } );
    exitButton.addActionListener( new ActionListener(){
      public void actionPerformed( ActionEvent ae ){
        print_base();
        System.exit(0);
      }
    } );
}

public void destroy(){
  //System.out.println("Final base points:");
  print_base();
  removeMouseMotionListener(this); }

public void mouseMoved(MouseEvent e){}  //1.1 event handling

public void mouseDragged(MouseEvent e) {
  double H=(double) h1;
  double W=(double) w2;
  double X1, Y1, X2, Y2, x1, y1;
  int x = e.getX();  if (x < 0) x = 0;  if (x > w2) x = w2;
  if (x > w2-5) return;
  x1=(double) x;
  X1=minx+(x1/W)*(maxx-minx);
  int y = e.getY();  if (y < 0) y = 0;  if (y > h1) y = h1;
  y1=(double) y;
  if (logscale) {
    Y1=Math.exp(Math.log(miny)+(1-y1/H)*(Math.log(maxy)-Math.log(miny)));
  } else {
    Y1=miny+(1-y1/H)*(maxy-miny);
  }
   int iMin = 0;
   double Rmin = 1e10, r2,xi,yi;
   if (x < 0) x = 0;
   for (int i = 0; i < n; i++){
    X2=Px[i];
    Y2=Py[i];
    xi = (X1-X2)/(maxx-minx); yi = (Y1-Y2)/(maxy-miny);
    r2 = xi*xi + yi*yi;
    if ( r2 < Rmin ){ iMin = i; Rmin = r2;}}
   Px[iMin] = X1; Py[iMin] = Y1;
  drawDATA();
  drawSpline();
  repaint();
}

public void drawline(double x1, double y1, double x2, double y2){
    double H=(double) h1;
    double W=(double) w2;
    double Y1, Y2;

    double X1=W*(x1-minx)/(maxx-minx);
    if (logscale) {
	    Y1=H*(1-(Math.log(y1)-Math.log(miny))/(Math.log(maxy)-Math.log(miny)));
    } else {
	    Y1=H*(1-(y1-miny)/(maxy-miny));
    }
    double X2=W*(x2-minx)/(maxx-minx);
    if (logscale) {
	    Y2=H*(1-(Math.log(y2)-Math.log(miny))/(Math.log(maxy)-Math.log(miny)));
    } else {
	    Y2=H*(1-(y2-miny)/(maxy-miny));
    }
    buffGraphics.drawLine((int)X1,(int)Y1, (int)X2,(int)Y2);
}

public void drawpoint(double x1, double y1){
    double H=(double) h1;
    double W=(double) w2;
    double Y1, Y2;

    double X1=W*(x1-minx)/(maxx-minx);
    if (logscale) {
	    Y1=H*(1-(Math.log(y1)-Math.log(miny))/(Math.log(maxy)-Math.log(miny)));
    } else {
	    Y1=H*(1-(y1-miny)/(maxy-miny));
    }
    buffGraphics.drawRect((int)X1-1,(int)Y1-1, 3,3);
}

public void drawDATA(){
  double X, Y, Xo, Yo;
  buffGraphics.clearRect(0,0, w2, h);
//Draw axis:
  buffGraphics.setColor(Color.black);
  buffGraphics.drawLine(0,h1, w2,h1);
//Draw data:
  buffGraphics.setColor(Color.green);
  if ( dat_n > 2 ){
   Xo = dat_x[0]; Yo = dat_y[0];
   for (int i = 1; i < dat_n; i++){
    X = dat_x[i];  Y = dat_y[i];
    drawline(Xo,Yo, X,Y);
    Xo = X;  Yo = Y;}
  }
}

public void print_base(){
  for (int i = 0; i < n; i++){
  System.out.println(Px[i]+" "+Py[i]);
  }
}

public void add_new(){
  int iMax = 0;
  double Rmax = 0, X1, X2, Y1, Y2, r2,xi,yi;
  for (int i = 0; i < n-1; i++){
    X1=Px[i];
    Y1=Py[i];
    X2=Px[i+1];
    Y2=Py[i+1];
    xi = (X1-X2)/(maxx-minx); yi = (Y1-Y2)/(maxy-miny);
    r2 = xi*xi + yi*yi;
    if ( r2 > Rmax ){ iMax = i; Rmax = r2;}
  }
  int on=n;
  double cx=(Px[iMax]+Px[iMax+1])/2, cy=bgp_spline(cx);
  n+=1;
  for (int i = on-1; i > iMax; i--){
    Px[i+1]=Px[i];
    Py[i+1]=Py[i];
  }
  Px[iMax+1]=cx;
  Py[iMax+1]=cy;
  drawDATA();
  drawSpline();
  repaint();
}

public void drawSpline(){
  double X,Y,cur_x,next_x;
//Draw points:
  buffGraphics.setColor(Color.blue);
  for (int i = 0; i < n; i++){
   X = Px[i];  Y = Py[i];
   drawpoint(X,Y);}
//Draw lines:
/*
  if ( n > 2 ){
   double Xo = Px[0], Yo = Py[0];
   for (int i = 1; i < n; i++){
    X = Px[i];  Y = Py[i];
    drawline(Xo,Yo, X,Y);
    Xo = X;  Yo = Y;}
  }
*/
//Draw spline:
  buffGraphics.setColor(Color.red);
  double Xo = Px[0], Yo = Py[0];
  for (int i = 1; i < n; i++){
    X = Px[i];  Y = Py[i];
    for (int k = 1; k < 100; k++){
	cur_x=Xo+k*(X-Xo)/100;
	next_x=Xo+(k+1)*(X-Xo)/100;
	drawline(cur_x,bgp_spline(cur_x), next_x,bgp_spline(next_x));
    }
    Xo = X;  Yo = Y;
  }
}

public void paint( Graphics g )
{
   super.paint(g);
   g.drawImage(buffImage, 0, 0, this);
}

/*
public void update(Graphics g){paint(g);}
*/

}
