#! /usr/local/bin/zsh -f
PATH="/home/ribarik/CMWP-121207/progs/bin:/home/ribarik/CMWP-121207/progs/jre1.6.0_12/bin:/home/ribarik/CMWP-121207/progs/libexec/gnuplot/4.2:/home/ribarik/bin.scripts:/home/ribarik/bin.sun4m:/home/ribarik/bin:/usr/local/tool:/usr/local/bin:/usr/local/sbin:/usr/local/samba/bin:/usr/local/bin/TeX:/usr/local/ssl/bin:/usr/local/etc:/usr/local/nmh/bin:/usr/etc:/etc:/usr/hosts:/usr/openwin/bin:/usr/openwin/demo/:/usr/bin/X11:/usr/ucb:/usr/bin:/usr/sbin:/sbin:/bin:/usr/games:/usr/dt/bin:/usr/ccs/bin:/usr/java1.1/bin:/opt/SUNWspro/bin:/opt/SUNWste/bin/:/usr/sadm/bin:/usr/xpg4/bin:/usr/proc/bin:/usr/vmsys/bin:/opt/SUNWrtvc/bin:./bin:.:/usr/local/bin:/usr/bin:/bin:/usr/share/lib:/usr/ccs/bin:/usr/xpg4/bin:$PATH"
# Copyright (C) G�bor Rib�rik, 1998-2009. All rights reserved.
# For permission to use, copy, modify this program or any of its components,
# see the file CMWP_COPYRIGHT.

export LC_ALL="POSIX"
if [[ ! -z $1 ]]
then
	file=$1
fi
vared -c -p 'Data file> ' file
echo "Plotting the data file."
cat >$$.gnu <<EOF
set logscale y
plot "$file" using 1:2 w lines
pause -1 'Press ENTER to continue.'
EOF
gnuplot $$.gnu
echo "The program cuts the data in the range [x1:x2]."
vared -c -p 'x1> ' x1
vared -c -p 'x2> ' x2
cat $file|tr -d "\r"|gawk '!($1>'"${x1}"' && $1<'"${x2}"') {print}' >$file.new
y1=$(cat $file|tr -d "\r"|gawk '($1>'"${x1}"' && $1<'"${x2}"') {print $2}'|head -1)
y2=$(cat $file|tr -d "\r"|gawk '($1>'"${x1}"' && $1<'"${x2}"') {print $2}'|tail -1)
./lib/fillspaces-auto $file.new $x1 $y1 $x2 $y2
echo "Plotting the new data file."
cat >$$.gnu <<EOF
set logscale y
plot "$file.new" using 1:2 w lines
pause -1 'Press ENTER to continue.'
EOF
gnuplot $$.gnu
q="n"
vared -c -p 'Should I replace the data file with the new one?> ' q
if [[ $q = [yYiI]* ]]
then
	mv $file.new $file
fi
