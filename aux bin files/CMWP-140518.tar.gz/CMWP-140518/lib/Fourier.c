/* Copyright (C) G�bor Rib�rik, 2000-2001. All rights reserved. Before using,
   copying or modifying this program or any of its components, please read
   first the file MKDAT_COPYRIGHT.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifndef PI
#define PI 3.14159265358979323846264338327950288
#endif

int main(int argc, char** argv)
{
    float tmp;
    float xf;
    float ff;
    double *x;
    double *xs;
    double *cosxs;
    double *sinxs;
    double *f;
    double mins, maxs, ds, s, S, cp, sp, dx;
    int size, dsize, i, j, maxi, N;
    FILE* fp;

    dsize=100;
    size=dsize;
    if ((x=(double *)malloc(size*sizeof(double))) == NULL ||
	(xs=(double *)malloc(size*sizeof(double))) == NULL ||
	(cosxs=(double *)malloc(size*sizeof(double))) == NULL ||
	(sinxs=(double *)malloc(size*sizeof(double))) == NULL ||
	(f=(double *)malloc(size*sizeof(double))) == NULL) {
      fprintf(stderr, "malloc() failed.\n");
      fflush(stderr);
      exit(1);
    }

    sscanf(argv[2], "%f", &tmp);
    mins=(double) tmp;
    sscanf(argv[3], "%f", &tmp);
    maxs=(double) tmp;
    sscanf(argv[4], "%d", &N);

    /*
    printf("mins=%f, maxs=%f, N=%d\n", mins, maxs, N);
    */

    fp=fopen(argv[1], "r");
    if(fp==NULL) {
	fprintf (stderr, "Error opening file.\n");
	exit(0);
    }

    i=0;
    while (!feof(fp)) {
      if (i>=size) {
	size+=dsize;
	if ((x=realloc(x, size*sizeof(double))) == NULL ||
	    (xs=realloc(xs, size*sizeof(double))) == NULL ||
	    (cosxs=realloc(cosxs, size*sizeof(double))) == NULL ||
	    (sinxs=realloc(sinxs, size*sizeof(double))) == NULL ||
	    (f=realloc(f, size*sizeof(double))) == NULL) {
	  fprintf(stderr, "realloc() failed.\n");
	  fflush(stderr);
	  exit(1);
	}
      }
      fscanf (fp, "%f %f\n", &xf, &ff);
      *(x+i)=(double) xf;
      *(f+i)=(double) ff;
      i++;
    }
    maxi=i;

    ds=(maxs-mins)/N;

    for (s=mins, j=0; j<N; s+=ds, j++) {
      S=2*PI*s;
      for (i=0; i<maxi; i++) {
	*(xs+i)=S*(*(x+i));
	*(cosxs+i)=cos(*(xs+i));
	*(sinxs+i)=sin(*(xs+i));
      }
      cp=0.0;
      sp=0.0;
      for (i=0; i<maxi-1; i++) {
	dx=0.5*(*(x+i+1)-*(x+i));
	cp+=(*(f+i)*(*(cosxs+i))+*(f+i+1)*(*(cosxs+i+1)))*dx;
	sp+=(*(f+i)*(*(sinxs+i))+*(f+i+1)*(*(sinxs+i+1)))*dx;
      }
      printf("%.15g %.15g %.15g %.15g\n", s, cp, (-1.0)*sp, sqrt(cp*cp+sp*sp));
    }

    fclose(fp);

    free(x);
    free(xs);
    free(cosxs);
    free(sinxs);
    free(f);

    return 0;
}
