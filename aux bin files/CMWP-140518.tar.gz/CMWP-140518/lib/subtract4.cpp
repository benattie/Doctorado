/* Copyright: one of my students, this was one of their homeworks. I'll check
   for his name and I'll write it here. Gabor Ribarik */
#include <iostream.h>
#include <iomanip.h>
#include <fstream.h>
#include <stdlib.h>

void quit(char *t){
    cout<<t<<endl;
    cout<<"Usage: subtract4 <first filename> <second filename>"<<endl;

    exit(0);
}

class series_cl{
    public:
	double *x;
	double *y;
	int dlen;

	series_cl(void){
	    x=y=NULL;
	    dlen=0;
	}	
	series_cl(char *t){
	    ifstream f(t);
	    
	    x=y=NULL;
	    dlen=0;
	    if(f.fail()) return;
	    
            cout<<"data read begin."<<endl;
	    for(;;){
		x=(double*)realloc(x,sizeof(double)*(dlen+1));
		y=(double*)realloc(y,sizeof(double)*(dlen+1));		
		f>>x[dlen];
		if (!(fabs(log(fabs(x[dlen])))<100)) {
                x[dlen]=0;		
		}
//		cout<<x[dlen];
		f>>y[dlen];
		if (!(fabs(log(fabs(y[dlen])))<100)) {
                y[dlen]=0;
		}
//		cout<<" "<<y[dlen]<<endl;
		if(f.eof()) break;
		if(dlen>100000) break;
		
		dlen++;
	    }
            cout<<"data read end."<<endl;
	    f.close();
	}
	~series_cl(){
	    free(x);
	    free(y);
	}
	
	int part(int myp,series_cl *si,ofstream *f){
	    int p1,p2;
	    int a;
	
	    for(p1=0;p1<si->dlen && si->x[p1]<=x[myp];p1++);
	    for(p2=p1;p2>=0 && si->x[p2]>=x[myp];p2--);
	    if(p1==si->dlen || p2<=0) return -1;
	    
    
	    *f<<x[myp]<<" "<<y[myp]<<" "<<si->y[p2]+(si->y[p1]-si->y[p2])*(x[myp]-si->x[p2])/(si->x[p1]-si->x[p2])<<" "<<-(si->y[p2]+(si->y[p1]-si->y[p2])*(x[myp]-si->x[p2])/
		(si->x[p1]-si->x[p2]) - y[myp])<<endl;
	    
    	    return 0;
	}
	
	void interpolate(series_cl *si,char *fn){
	    ofstream f(fn,ios::trunc);
	
	    for(int a=0;a<dlen;a++)
		part(a,si,&f);
	    f.close();
	}
};

int main(int argc,char **argv){
    if(argc<3) quit("Error: bad number of arguments.");
    
    series_cl s1(argv[1]);
    series_cl s2(argv[2]);    

    s1.interpolate(&s2,"2.1.out");
    cout<<"The output has been saved in file 2.1.out."<<endl;
}
